# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: render-race-reproduction.spec.ts >> controlled reset render race loses the old opener before Enter at 1366px
- Location: tests/e2e/specs/render-race-reproduction.spec.ts:38:5

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('dialog', { name: 'Expanded persisted metric' })
Expected substring: "2026-09-10T09:00:00Z"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" getByRole('dialog', { name: 'Expanded persisted metric' }) with timeout 5000ms
  - waiting for getByRole('dialog', { name: 'Expanded persisted metric' })

```

```yaml
- link "Skip to workspace":
  - /url: "#workspace"
- complementary:
  - link "TraceLink — Service overview":
    - /url: /dashboard
  - navigation "Workspace":
    - link "Service overview":
      - /url: /dashboard
    - link "Trace Link history":
      - /url: /trace-link
  - link "VoLTE setup":
    - /url: /services/VOLTE-MD-CENTRAL
  - link "Roaming preview":
    - /url: /roaming
  - link "Incident investigation":
    - /url: /dashboard#incident-queue
  - button "Expand sidebar"
- banner:
  - text: Workspace /
  - strong: Trace Link history
  - text: Session connected
  - button "Notifications, 0 unread": Notifications
  - text: CO Controlled analyst ANALYST · until 19:06 UTC
  - button "Sign out"
- main:
  - heading "Trace Link history" [level=1]
  - paragraph: Synthetic persisted measurements and versioned inventory. No preview values.
  - region "Shared history query":
    - text: Dataset ID
    - textbox "Dataset ID":
      - /placeholder: Recorded dataset ID
      - text: trace-link-md-30d-v1
    - text: From · UTC inclusive
    - textbox "From · UTC inclusive": 2026-09-10T09:00:00Z
    - text: To · UTC exclusive
    - textbox "To · UTC exclusive": 2026-09-10T09:20:00Z
    - text: Resolution
    - combobox "Resolution":
      - option "5m" [selected]
      - option "15m"
      - option "1h"
      - option "6h"
    - text: Timezone
    - combobox "Timezone":
      - option "UTC" [selected]
      - option "Europe/Chisinau"
    - text: City
    - combobox "City":
      - option "Choose a city for series"
      - option "Chișinău" [selected]
      - option "Bălți"
      - option "Cahul"
      - option "Ungheni"
      - option "Orhei"
      - option "Soroca"
      - option "Comrat"
      - option "Edineț"
      - option "Hîncești"
      - option "Căușeni"
    - paragraph: Use UTC timestamps ending in Z. Maximum selected period is 30 days. Native history is five minutes; period and resolution are independent.
    - button "Apply history query"
    - button "6h"
    - button "24h"
    - button "48h"
    - button "7d"
    - button "14d"
    - button "30d"
    - paragraph: Selected [2026-09-10T09:00:00Z, 2026-09-10T09:20:00Z). Visible [2026-09-10T09:00:00Z, 2026-09-10T09:20:00Z).
    - button "Zoom in"
    - button "Pan earlier"
    - button "Pan later"
    - button "Reset zoom"
  - region "Approved topology":
    - heading "Active reference topology" [level=2]
    - paragraph: Catalogue controlled-native-v1 · 10 active cities · 12 active links. Declared directions and capacity are inventory, not measured traffic or source authority.
    - group "Versioned city and link topology; equivalent selection table follows":
      - button "Select city Chișinău": Chișinău
      - button "Select city Bălți": Bălți
      - button "Select city Cahul": Cahul
      - button "Select city Ungheni": Ungheni
      - button "Select city Orhei": Orhei
      - button "Select city Soroca": Soroca
      - button "Select city Comrat": Comrat
      - button "Select city Edineț": Edineț
      - button "Select city Hîncești": Hîncești
      - button "Select city Căușeni": Căușeni
    - group: City selection table
    - group:
      - text: Directional transport inventory
      - table:
        - rowgroup:
          - row "Link Endpoints Direction Effective Gbps Measurement source":
            - columnheader "Link"
            - columnheader "Endpoints"
            - columnheader "Direction"
            - columnheader "Effective Gbps"
            - columnheader "Measurement source"
        - rowgroup:
          - row "chi-orh chi → orh chi-orh a-to-b 20 controlled reference fixture":
            - rowheader "chi-orh"
            - cell "chi → orh"
            - cell "chi-orh a-to-b":
              - button "chi-orh a-to-b"
            - cell "20"
            - cell "controlled reference fixture"
          - row "chi-orh orh → chi chi-orh b-to-a 20 controlled reference fixture":
            - rowheader "chi-orh"
            - cell "orh → chi"
            - cell "chi-orh b-to-a":
              - button "chi-orh b-to-a"
            - cell "20"
            - cell "controlled reference fixture"
          - row "orh-sor orh → sor orh-sor a-to-b 10 controlled reference fixture":
            - rowheader "orh-sor"
            - cell "orh → sor"
            - cell "orh-sor a-to-b":
              - button "orh-sor a-to-b"
            - cell "10"
            - cell "controlled reference fixture"
          - row "orh-sor sor → orh orh-sor b-to-a 10 controlled reference fixture":
            - rowheader "orh-sor"
            - cell "sor → orh"
            - cell "orh-sor b-to-a":
              - button "orh-sor b-to-a"
            - cell "10"
            - cell "controlled reference fixture"
          - row "sor-bal sor → bal sor-bal a-to-b 10 controlled reference fixture":
            - rowheader "sor-bal"
            - cell "sor → bal"
            - cell "sor-bal a-to-b":
              - button "sor-bal a-to-b"
            - cell "10"
            - cell "controlled reference fixture"
          - row "sor-bal bal → sor sor-bal b-to-a 10 controlled reference fixture":
            - rowheader "sor-bal"
            - cell "bal → sor"
            - cell "sor-bal b-to-a":
              - button "sor-bal b-to-a"
            - cell "10"
            - cell "controlled reference fixture"
          - row "bal-edi bal → edi bal-edi a-to-b 10 controlled reference fixture":
            - rowheader "bal-edi"
            - cell "bal → edi"
            - cell "bal-edi a-to-b":
              - button "bal-edi a-to-b"
            - cell "10"
            - cell "controlled reference fixture"
          - row "bal-edi edi → bal bal-edi b-to-a 10 controlled reference fixture":
            - rowheader "bal-edi"
            - cell "edi → bal"
            - cell "bal-edi b-to-a":
              - button "bal-edi b-to-a"
            - cell "10"
            - cell "controlled reference fixture"
          - row "bal-ung bal → ung bal-ung a-to-b 20 controlled reference fixture":
            - rowheader "bal-ung"
            - cell "bal → ung"
            - cell "bal-ung a-to-b":
              - button "bal-ung a-to-b"
            - cell "20"
            - cell "controlled reference fixture"
          - row "bal-ung ung → bal bal-ung b-to-a 20 controlled reference fixture":
            - rowheader "bal-ung"
            - cell "ung → bal"
            - cell "bal-ung b-to-a":
              - button "bal-ung b-to-a"
            - cell "20"
            - cell "controlled reference fixture"
          - row "ung-chi ung → chi ung-chi a-to-b 20 controlled reference fixture":
            - rowheader "ung-chi"
            - cell "ung → chi"
            - cell "ung-chi a-to-b":
              - button "ung-chi a-to-b"
            - cell "20"
            - cell "controlled reference fixture"
          - row "ung-chi chi → ung ung-chi b-to-a 20 controlled reference fixture":
            - rowheader "ung-chi"
            - cell "chi → ung"
            - cell "ung-chi b-to-a":
              - button "ung-chi b-to-a"
            - cell "20"
            - cell "controlled reference fixture"
          - row "chi-hin chi → hin chi-hin a-to-b 20 controlled reference fixture":
            - rowheader "chi-hin"
            - cell "chi → hin"
            - cell "chi-hin a-to-b":
              - button "chi-hin a-to-b"
            - cell "20"
            - cell "controlled reference fixture"
          - row "chi-hin hin → chi chi-hin b-to-a 20 controlled reference fixture":
            - rowheader "chi-hin"
            - cell "hin → chi"
            - cell "chi-hin b-to-a":
              - button "chi-hin b-to-a"
            - cell "20"
            - cell "controlled reference fixture"
          - row "hin-com hin → com hin-com a-to-b 10 controlled reference fixture":
            - rowheader "hin-com"
            - cell "hin → com"
            - cell "hin-com a-to-b":
              - button "hin-com a-to-b"
            - cell "10"
            - cell "controlled reference fixture"
          - row "hin-com com → hin hin-com b-to-a 10 controlled reference fixture":
            - rowheader "hin-com"
            - cell "com → hin"
            - cell "hin-com b-to-a":
              - button "hin-com b-to-a"
            - cell "10"
            - cell "controlled reference fixture"
          - row "com-cah com → cah com-cah a-to-b 10 controlled reference fixture":
            - rowheader "com-cah"
            - cell "com → cah"
            - cell "com-cah a-to-b":
              - button "com-cah a-to-b"
            - cell "10"
            - cell "controlled reference fixture"
          - row "com-cah cah → com com-cah b-to-a 10 controlled reference fixture":
            - rowheader "com-cah"
            - cell "cah → com"
            - cell "com-cah b-to-a":
              - button "com-cah b-to-a"
            - cell "10"
            - cell "controlled reference fixture"
          - row "chi-cau chi → cau chi-cau a-to-b 10 controlled reference fixture":
            - rowheader "chi-cau"
            - cell "chi → cau"
            - cell "chi-cau a-to-b":
              - button "chi-cau a-to-b"
            - cell "10"
            - cell "controlled reference fixture"
          - row "chi-cau cau → chi chi-cau b-to-a 10 controlled reference fixture":
            - rowheader "chi-cau"
            - cell "cau → chi"
            - cell "chi-cau b-to-a":
              - button "chi-cau b-to-a"
            - cell "10"
            - cell "controlled reference fixture"
          - row "cau-com cau → com cau-com a-to-b 10 controlled reference fixture":
            - rowheader "cau-com"
            - cell "cau → com"
            - cell "cau-com a-to-b":
              - button "cau-com a-to-b"
            - cell "10"
            - cell "controlled reference fixture"
          - row "cau-com com → cau cau-com b-to-a 10 controlled reference fixture":
            - rowheader "cau-com"
            - cell "com → cau"
            - cell "cau-com b-to-a":
              - button "cau-com b-to-a"
            - cell "10"
            - cell "controlled reference fixture"
          - row "orh-bal orh → bal orh-bal a-to-b 20 controlled reference fixture":
            - rowheader "orh-bal"
            - cell "orh → bal"
            - cell "orh-bal a-to-b":
              - button "orh-bal a-to-b"
            - cell "20"
            - cell "controlled reference fixture"
          - row "orh-bal bal → orh orh-bal b-to-a 20 controlled reference fixture":
            - rowheader "orh-bal"
            - cell "bal → orh"
            - cell "orh-bal b-to-a":
              - button "orh-bal b-to-a"
            - cell "20"
            - cell "controlled reference fixture"
  - region "Persisted domain panels":
    - heading "Persisted domain metrics" [level=2]
    - button "VoLTE" [pressed]
    - button "Transport"
    - button "Roaming"
    - button "SMS"
    - button "LTE mobile data"
    - text: Metric
    - combobox "Metric":
      - option "voice.success_rate" [selected]
    - paragraph: VoLTE call attempts in the selected city · RATIO_OF_SUMS · policy trace-link-md-policy-v1
    - paragraph:
      - text: Synthetic · dataset
      - code: trace-link-md-30d-v1
      - text: · CITY chi · topology trace-link-md-topology-v1 · source resolution 300 seconds · Full edge buckets
    - region "Persisted metric chart":
      - paragraph: voice.success_rate · PERCENT · RATIO_OF_SUMS. Baseline unavailable in this read contract. Gaps indicate unavailable observations.
      - img "voice.success_rate in PERCENT; exact values follow in the table": 50 PERCENT 0 PERCENT
      - group:
        - text: Exact server buckets · 4 rows
        - table:
          - rowgroup:
            - row "Start · UTC End Value · PERCENT Quality Coverage Numerator Denominator Sum Samples":
              - columnheader "Start · UTC"
              - columnheader "End"
              - columnheader "Value · PERCENT"
              - columnheader "Quality"
              - columnheader "Coverage"
              - columnheader "Numerator"
              - columnheader "Denominator"
              - columnheader "Sum"
              - columnheader "Samples"
          - rowgroup:
            - row "10/09/2026, 09:00:00 10/09/2026, 09:05:00 0 VALID 1 0 10 Unavailable Unavailable":
              - rowheader "10/09/2026, 09:00:00":
                - time: 10/09/2026, 09:00:00
              - cell "10/09/2026, 09:05:00"
              - cell "0"
              - cell "VALID"
              - cell "1"
              - cell "0"
              - cell "10"
              - cell "Unavailable"
              - cell "Unavailable"
            - row "10/09/2026, 09:05:00 10/09/2026, 09:10:00 Unavailable · zero denominator INSUFFICIENT_EVIDENCE 1 0 0 Unavailable Unavailable":
              - rowheader "10/09/2026, 09:05:00":
                - time: 10/09/2026, 09:05:00
              - cell "10/09/2026, 09:10:00"
              - cell "Unavailable · zero denominator"
              - cell "INSUFFICIENT_EVIDENCE"
              - cell "1"
              - cell "0"
              - cell "0"
              - cell "Unavailable"
              - cell "Unavailable"
            - row "10/09/2026, 09:10:00 10/09/2026, 09:15:00 50 VALID 1 5 10 Unavailable Unavailable":
              - rowheader "10/09/2026, 09:10:00":
                - time: 10/09/2026, 09:10:00
              - cell "10/09/2026, 09:15:00"
              - cell "50"
              - cell "VALID"
              - cell "1"
              - cell "5"
              - cell "10"
              - cell "Unavailable"
              - cell "Unavailable"
            - row "10/09/2026, 09:15:00 10/09/2026, 09:20:00 45 STALE 1 9 10 Unavailable Unavailable":
              - rowheader "10/09/2026, 09:15:00":
                - time: 10/09/2026, 09:15:00
              - cell "10/09/2026, 09:20:00"
              - cell "45"
              - cell "STALE"
              - cell "1"
              - cell "9"
              - cell "10"
              - cell "Unavailable"
              - cell "Unavailable"
        - button "Previous buckets" [disabled]
        - text: Page 1 of 1
        - button "Next buckets" [disabled]
    - button "Expand metric"
    - button "Download exact server CSV"
    - paragraph: Grafana connectivity and new-domain incident mapping are unavailable in this candidate. Existing incident investigation remains available through the workspace navigation.
```

# Test source

```ts
  1  | import { test, expect, type Page } from '@playwright/test';
  2  | import { readFileSync } from 'node:fs';
  3  | import { resolve } from 'node:path';
  4  | import { controlledApi } from '../helpers/controlled-api';
  5  | 
  6  | const csvRows=(name:string)=>{
  7  |   const [header,...lines]=readFileSync(resolve(__dirname,`../../../../../contracts/fixtures/trace-link/native-slice/${name}.csv`),'utf8').trim().split(/\r?\n/);
  8  |   return lines.map(line=>Object.fromEntries(header.split(',').map((key,index)=>[key,line.split(',')[index]])));
  9  | };
  10 | const active={active:true,validFrom:'2026-09-10T09:00:00Z',validTo:null,synthetic:true};
  11 | const cities=csvRows('cities').map(city=>({...active,id:city.id,name:city.name,latitude:+city.latitude,longitude:+city.longitude,demandShare:+city.demand_share}));
  12 | const links=csvRows('links').map(link=>({...active,id:link.id,endpointA:link.a,endpointB:link.b,linkType:'FIBER',nominalCapacityGbps:+link.nominal_capacity_gbps,
  13 |   directions:['a-to-b','b-to-a'].map(id=>({id,effectiveCapacityGbps:+link.nominal_capacity_gbps,capacityValidFrom:active.validFrom,capacityValidTo:null,measurementSource:'controlled reference fixture'}))}));
  14 | const partners=csvRows('countries').flatMap(country=>['in','out'].map(direction=>({...active,id:country.partner_id,country:country.id,direction})));
  15 | const definition={domain:'volte',metric:'voice.success_rate',unit:'PERCENT',aggregation:'RATIO_OF_SUMS',population:'VoLTE call attempts in the selected city',primitiveFields:['numerator','denominator'],policyVersion:'trace-link-md-policy-v1'};
  16 | const queryUrl='/trace-link?datasetId=trace-link-md-30d-v1&from=2026-09-10T09%3A00%3A00Z&to=2026-09-10T09%3A20%3A00Z&resolution=5m&cityId=chi';
  17 | const exactCsv='from,value,numerator,denominator\r\n"2026-09-10T09:00:00Z","0","0","10"\r\n"2026-09-10T09:05:00Z",,"0","0"\r\n';
  18 | function series(url:URL){
  19 |   const params=Object.fromEntries(url.searchParams),seconds=({'5m':300,'15m':900,'1h':3600,'6h':21600} as Record<string,number>)[params.resolution];
  20 |   const from=Math.floor(Date.parse(params.from)/(seconds*1000))*seconds*1000,to=Math.ceil(Date.parse(params.to)/(seconds*1000))*seconds*1000;
  21 |   return {...params,requestedFrom:params.from,requestedTo:params.to,effectiveFrom:new Date(from).toISOString(),effectiveTo:new Date(to).toISOString(),partialStart:from!==Date.parse(params.from),partialEnd:to!==Date.parse(params.to),sourceResolutionSeconds:300,unit:'PERCENT',aggregation:'RATIO_OF_SUMS',synthetic:true,policyVersion:definition.policyVersion,topologyVersion:'trace-link-md-topology-v1',nextCursor:null,
  22 |     points:Array.from({length:(to-from)/seconds/1000},(_,index)=>({from:new Date(from+index*seconds*1000).toISOString(),to:new Date(from+(index+1)*seconds*1000).toISOString(),value:[0,null,50,45][index%4],coverage:1,quality:index%4===3?'STALE':index%4===1?'INSUFFICIENT_EVIDENCE':'VALID',numerator:index%4===1?0:[0,0,5,9][index%4],denominator:index%4===1?0:10,sumValue:null,sampleCount:null}))};
  23 | }
  24 | async function setup(page:Page){
  25 |   await controlledApi(page);const queries:Record<string,string>[]=[];
  26 |   await page.route('**/api/v2/**',route=>{
  27 |     const url=new URL(route.request().url());
  28 |     if(url.pathname==='/api/v2/inventory/cities')return route.fulfill({json:{catalogueVersion:'controlled-native-v1',cities}});
  29 |     if(url.pathname==='/api/v2/inventory/links')return route.fulfill({json:{catalogueVersion:'controlled-native-v1',links}});
  30 |     if(url.pathname==='/api/v2/inventory/partners')return route.fulfill({json:{catalogueVersion:'controlled-native-v1',partners}});
  31 |     if(url.pathname==='/api/v2/kpi-definitions')return route.fulfill({json:[definition]});
  32 |     queries.push(Object.fromEntries(url.searchParams));
  33 |     if(url.pathname.endsWith('.csv'))return route.fulfill({contentType:'text/csv;charset=utf-8',body:exactCsv});
  34 |     return route.fulfill({json:series(url)});
  35 |   });return queries;
  36 | }
  37 | 
  38 | test('controlled reset render race loses the old opener before Enter at 1366px', async ({page}, info) => {
  39 |   await setup(page); await page.setViewportSize({width:1366,height:900}); await page.goto(queryUrl);
  40 |   const expand=page.getByRole('button',{name:'Expand metric',exact:true});
  41 |   await expect(expand).toBeVisible(); const oldOpener=await expand.elementHandle();
  42 |   let release!:()=>void, requested=false;
  43 |   await page.route('**/api/v2/metrics/series?**',async route=>{
  44 |     requested=true; await new Promise<void>(resolve=>release=resolve);
  45 |     await route.fulfill({json:series(new URL(route.request().url()))});
  46 |   });
  47 |   // Force the permitted interleaving: query event, focus, then Angular's scheduled render.
  48 |   const focusedBeforeRender=await page.evaluate(()=>{
  49 |     const buttons=Array.from(document.querySelectorAll('button'));
  50 |     (buttons.find(button=>button.textContent==='Reset zoom') as HTMLButtonElement).click();
  51 |     const opener=buttons.find(button=>button.textContent==='Expand metric')!; opener.focus();
  52 |     return document.activeElement===opener;
  53 |   });
  54 |   expect(focusedBeforeRender).toBe(true);
  55 |   await expect.poll(()=>requested).toBe(true);
  56 |   await expect.poll(()=>oldOpener!.evaluate(element=>element.isConnected)).toBe(false);
  57 |   release(); await expect(expand).toBeVisible();
  58 |   const focusAfterRender=await page.evaluate(()=>document.activeElement?.tagName);
  59 |   console.log(JSON.stringify({focusedBeforeRender,oldOpenerDetached:true,focusAfterRender}));
  60 |   await page.keyboard.press('Enter');
> 61 |   await expect(page.getByRole('dialog',{name:'Expanded persisted metric'})).toContainText('2026-09-10T09:00:00Z');
     |                                                                             ^ Error: expect(locator).toContainText(expected) failed
  62 | });
  63 | 
```