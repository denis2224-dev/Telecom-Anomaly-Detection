function Invoke-CorrectionGate {
    param([string]$Name,[string]$Executable,[string[]]$Arguments)
    $gateStart=[DateTime]::UtcNow
    $gateCommit=(& git rev-parse HEAD).Trim()
    $gateLog=Join-Path (Get-Location) ('target/correction-checks/'+$Name+'.log')
    $gateCode=1
    try { & $Executable @Arguments *> $gateLog; $gateCode=$LASTEXITCODE }
    catch { $_ | Out-String | Add-Content -LiteralPath $gateLog }
    @{name=$Name;executable=$Executable;arguments=$Arguments;workingDirectory=(Get-Location).Path;
      sourceCommit=$gateCommit;startedAt=$gateStart.ToString('o');finishedAt=[DateTime]::UtcNow.ToString('o');
      exitCode=$gateCode;log=$gateLog;trackedWorkingTreeDirty=[bool](& git status --porcelain --untracked-files=no)} |
      ConvertTo-Json -Depth 8 | Set-Content -Encoding utf8 -LiteralPath ($gateLog+'.execution.json')
    Get-Content -LiteralPath $gateLog -Tail 28 | ForEach-Object { Write-Host $_ }
    return $gateCode
}
