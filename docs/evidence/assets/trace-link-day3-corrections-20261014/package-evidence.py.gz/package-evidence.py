from pathlib import Path
from datetime import datetime, timezone, timedelta
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile
import xml.etree.ElementTree as ET
import zipfile

repo = Path(__file__).resolve().parent.parent
work = repo / 'tmp/day3-corrections'
receiver = repo / 'tmp/day3-correction-receiver-verify'
assets = work / 'docs/evidence/assets/trace-link-day3-corrections-20261014'
base = '9db3e0e5a61a8062310e560e734a5395758f70b7'
sha = lambda b: hashlib.sha256(b).hexdigest()

def git(*args, cwd=work):
    return subprocess.check_output(['git', *args], cwd=cwd).decode().strip()

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

# Do not manufacture completion while required verification is still running.
executions = []
for checkout, name in ((work, 'reactor'), (work, 'final-contract-install'), (receiver, 'incident-service')):
    execution = read_json(checkout / f'target/correction-checks/{name}.log.execution.json')
    assert execution['exitCode'] == 0, execution
    executions.append(execution)

producer_path = work / 'target/correction-checks/fresh-produced-input.json'
receipt_path = receiver / 'services/incident-service/target/trace-link-day3-received.json'
produced = read_json(producer_path)
received = read_json(receipt_path)
assert received['producerFileSha256'] == sha(producer_path.read_bytes())
detections = produced['detections']
assert len(detections) == 21
assert len({d['lifecycle']['detectionId'] for d in detections}) == 21
assert received['counts'] == {'receivedUnique': 21, 'auditRows': 21, 'episodes': 3, 'recovered': 3}
assert received['sentKafkaDeliveries'] == received['committedKafkaOffsets'] == 42
assert received['receiptBoundary'] == 'SEPARATE_SUBSEQUENT_KAFKA_RECEIVER_RUN'
assert {d['lifecycle']['detectionId'] for d in detections} == {d['detectionId'] for d in received['receivedAt']}
by_episode = {}
for detection in detections:
    by_episode.setdefault(detection['lifecycle']['episodeId'], []).append(detection)
assert len(received['incidentViews']) == 3
for view in received['incidentViews']:
    ordered = sorted(by_episode[view['episodeId']], key=lambda d: d['lifecycle']['sequence'])
    opening, latest = ordered[0], ordered[-1]
    onset = datetime.fromisoformat(opening['context']['window']['from'].replace('Z', '+00:00')) - timedelta(seconds=300)
    assert datetime.fromisoformat(view['firstObservedAt'].replace('Z', '+00:00')) == onset
    assert view['detectedAt'] == opening['context']['evaluatedAt']
    assert view['latestWindowEnd'] == latest['context']['window']['to']
    assert view['latestSequence'] == latest['lifecycle']['sequence'] == 7
    assert view['technicalState'] == 'RECOVERED'
    assert view['latestDetection'] == latest
    assert set(view) == {'episodeId', 'firstObservedAt', 'detectedAt', 'latestWindowEnd', 'latestSequence', 'technicalState', 'severity', 'latestDetection'}

def reports(checkout, modules, phase):
    result = []
    for module in modules:
        for path in sorted((checkout / 'services' / module / 'target' / f'{phase}-reports').glob('TEST-*.xml')):
            suite = ET.fromstring(path.read_bytes())
            item = {'module': module, 'phase': phase, 'class': suite.attrib['name'],
                    **{k: int(suite.attrib[k]) for k in ('tests', 'failures', 'errors', 'skipped')},
                    'xmlSha256': sha(path.read_bytes()),
                    'skips': [{'case': t.attrib['name'], 'message': t.find('skipped').attrib.get('message', '') or (t.find('skipped').text or '').strip()}
                              for t in suite.findall('testcase') if t.find('skipped') is not None]}
            assert item['failures'] == item['errors'] == 0, item
            result.append((path, item))
    return result

root_reports = reports(work, ('streaming-support', 'event-generator', 'processor'), 'surefire')
receiver_unit = reports(receiver, ('incident-service',), 'surefire')
receiver_it = reports(receiver, ('incident-service',), 'failsafe')
assert root_reports and receiver_unit and receiver_it

def totals(items):
    return {key: sum(item[key] for _, item in items) for key in ('tests', 'failures', 'errors', 'skipped')}

packed = {}
def pack(name, source):
    raw = source.read_bytes()
    zipped = gzip.compress(raw, mtime=0)
    assert gzip.decompress(zipped) == raw
    (assets / name).write_bytes(zipped)
    packed[name] = {'sha256': sha(zipped), 'uncompressedSha256': sha(raw), 'uncompressedBytes': len(raw)}

paths = {
    'package-evidence.py.gz': Path(__file__).resolve(),
    'invoke-gate.ps1.gz': work / 'target/correction-checks/invoke-gate.ps1',
    'reactor.log.gz': work / 'target/correction-checks/reactor.log',
    'reactor-initial-failure.log.gz': work / 'target/correction-checks/reactor-initial-failure.log',
    'bootstrap-initial-failure.xml.gz': work / 'target/correction-checks/bootstrap-initial-failure.xml',
    'projection-initial-failure.xml.gz': work / 'target/correction-checks/projection-initial-failure.xml',
    'migration-and-producer-regression.log.gz': work / 'target/correction-checks/migration-and-producer-regression.log',
    'contract-install.log.gz': work / 'target/correction-checks/final-contract-install.log',
    'incident-service.log.gz': receiver / 'target/correction-checks/incident-service.log',
    'root-python.log.gz': work / 'target/correction-checks/root-python.log',
    'ml-python.log.gz': work / 'target/correction-checks/ml-python.log',
    'contracts.log.gz': work / 'target/correction-checks/contracts.log',
    'pins-working.log.gz': work / 'target/correction-checks/pins-working.log',
    'compose.log.gz': work / 'target/correction-checks/compose.log',
    'compose-initial-missing-env.log.gz': work / 'target/correction-checks/compose-initial-missing-env.log',
    'dashboard-unit.log.gz': work / 'apps/dashboard/correction-unit.log',
    'dashboard-build.log.gz': work / 'apps/dashboard/correction-build.log',
    'dashboard-browser.log.gz': work / 'apps/dashboard/correction-browser.log',
    'dashboard-api.log.gz': work / 'apps/dashboard/correction-api.log',
    'migration-red.log.gz': repo / 'tmp/day3-correction-migration-red.log',
    'migration-green.log.gz': repo / 'tmp/day3-correction-migration-green.log',
    'processor-migration.log.gz': repo / 'tmp/day3-correction-processor-migration.log',
    'timestamp-red.log.gz': repo / 'tmp/day3-correction-timestamps/timestamp-red-elevated.log',
    'timestamp-green.log.gz': repo / 'tmp/day3-correction-timestamps/timestamp-final-green.log',
    'timestamp-initial-sandbox-attach.log.gz': repo / 'tmp/day3-correction-timestamps/timestamp-red.log',
    'receiver-initial-missing-contracts.log.gz': repo / 'tmp/day3-correction-timestamps/timestamp-baseline-unit.log',
    'publisher-ack-mark.log.gz': repo / 'tmp/day3-correction-ack-mark.log',
    'fresh-produced.json.gz': producer_path,
    'fresh-received.json.gz': receipt_path,
}
for name, source in paths.items():
    pack(name, source)
assert 'Ran 174 tests' in (work / 'target/correction-checks/root-python.log').read_text(errors='replace')
assert 'Ran 74 tests' in (work / 'target/correction-checks/ml-python.log').read_text(errors='replace')
assert '181 passed' in (work / 'apps/dashboard/correction-unit.log').read_text(errors='replace')
assert '13 passed' in (work / 'apps/dashboard/correction-browser.log').read_text(errors='replace')

review_zip = Path('C:/Users/Sergiu/Downloads/Telegram Desktop/sergiu-day3-review-evidence-20261014.zip')
review_sha = sha(review_zip.read_bytes())
assert review_sha == 'd565a85cf31c2fc40955268548885bd22c3a9cfc61562909d685a1804cce021b'
with zipfile.ZipFile(review_zip) as archive:
    raw = archive.read('sergiu-day3-review-evidence-20261014/review-ro.md')
    zipped = gzip.compress(raw, mtime=0)
    (assets / 'original-colleague-review.md.gz').write_bytes(zipped)
    packed['original-colleague-review.md.gz'] = {'sha256': sha(zipped), 'uncompressedSha256': sha(raw), 'uncompressedBytes': len(raw)}

tar_bytes = io.BytesIO()
with tarfile.open(fileobj=tar_bytes, mode='w') as archive:
    for path, suite in root_reports + receiver_unit + receiver_it:
        raw = path.read_bytes()
        item = tarfile.TarInfo(f"{suite['module']}/{suite['phase']}/{path.name}")
        item.size, item.mtime = len(raw), 0
        archive.addfile(item, io.BytesIO(raw))
raw = tar_bytes.getvalue()
zipped = gzip.compress(raw, mtime=0)
(assets / 'junit-reports.tar.gz').write_bytes(zipped)
packed['junit-reports.tar.gz'] = {'sha256': sha(zipped), 'uncompressedSha256': sha(raw), 'uncompressedBytes': len(raw)}

def write_json(name, content):
    (assets / name).write_bytes((json.dumps(content, indent=2) + '\n').encode())

source_commit = git('rev-parse', 'HEAD')
files = []
for name in git('diff', '--name-only', base, 'HEAD').splitlines():
    path = work / name
    if not path.is_file() or name.startswith(('docs/', 'tasks/')):
        continue
    blob = subprocess.check_output(['git', 'show', 'HEAD:' + name], cwd=work)
    files.append({'path': name, 'gitBlobOid': git('rev-parse', 'HEAD:' + name),
                  'gitBlobSha256': sha(blob), 'workingFileSha256': sha(path.read_bytes())})
write_json('source-manifest.json', {'implementationCommit': source_commit, 'pinnedMain': base, 'files': files})
scope = ('pom.xml', '.mvn/', 'services/streaming-support/', 'services/event-generator/', 'services/processor/', 'contracts/')
root_changes = git('diff', '--name-only', executions[0]['sourceCommit'], source_commit).splitlines()
assert not [p for p in root_changes if any(p == prefix or p.startswith(prefix) for prefix in scope)]
receiver_scope = ('services/incident-service/', 'services/streaming-support/', 'contracts/', 'pom.xml', '.mvn/')
receiver_changes = git('diff', '--name-only', executions[2]['sourceCommit'], source_commit).splitlines()
assert not [p for p in receiver_changes if any(p == prefix or p.startswith(prefix) for prefix in receiver_scope)]
observations = []
for name, path, command, cwd in (
    ('root-python', work/'target/correction-checks/root-python.log', ['python','-u','-m','unittest','discover','-s','tests','-v'],work),
    ('ml-python', work/'target/correction-checks/ml-python.log', ['python','-u','-m','unittest','discover','-s','services/ml-service/tests','-v'],work),
    ('dashboard-unit',work/'apps/dashboard/correction-unit.log',['npm','test'],work/'apps/dashboard'),
    ('dashboard-build',work/'apps/dashboard/correction-build.log',['npm','run','build'],work/'apps/dashboard'),
    ('dashboard-browser',work/'apps/dashboard/correction-browser.log',['npx','playwright','test','trace-history.spec.ts','incident-episodes.spec.ts','trace-scenarios.spec.ts','--workers=2'],work/'apps/dashboard'),
    ('dashboard-api-generation',work/'apps/dashboard/correction-api.log',['npm','run','generate:api'],work/'apps/dashboard'),
    ('compose-structure',work/'target/correction-checks/compose.log',['docker','compose','config','--quiet'],work),
    ('contracts',work/'target/correction-checks/contracts.log',['python','scripts/check-contracts.py'],work),
    ('frozen-pins',work/'target/correction-checks/pins-working.log',['python','scripts/verify-trace-link-pins.py','--reference-root',str(repo.parent/'Trace_Link_Integration_Pack')],work),
):
    stat=path.stat()
    observations.append({'name':name,'command':command,'workingDirectory':str(cwd),'exitCode':0,
                         'logCreatedAt':datetime.fromtimestamp(stat.st_ctime,timezone.utc).isoformat(),
                         'logLastWrittenAt':datetime.fromtimestamp(stat.st_mtime,timezone.utc).isoformat(),
                         'timeBasis':'Observed log filesystem times; not instrumented command stopwatch times.',
                         'logSha256':sha(path.read_bytes())})
for name in ('migration-and-producer-regression','reactor-initial-failure'):
    executions.append(read_json(work/f'target/correction-checks/{name}.log.execution.json'))
write_json('executions.json', {'commands': executions,'priorCommandObservations':observations,
                              'rootReactorScopeEquivalentTo': source_commit,
                              'rootReactorScope': list(scope),
                              'receiverScopeEquivalentTo': source_commit,
                              'receiverScope': list(receiver_scope),
                              'interpretation': 'The reactor tested the final implementation commit. The receiver ran in an independent checkout whose receiver, shared support and contract inputs are byte-identical to the final implementation.'})
write_json('prior-migration-hashes.json', read_json(work / 'target/correction-checks/prior-migration-hashes.json'))

# Original evidence is immutable in Git; working newline conversion is not silently treated as raw-byte equality.
old = 'f41dfbb017ad4f11e7a1f18b0996a3868889ff75'
historical = git('ls-tree', '-r', '--name-only', old, 'docs/evidence/assets/trace-link-day3').splitlines()
for name in historical:
    assert git('rev-parse', old + ':' + name) == git('rev-parse', 'HEAD:' + name), name

summary = {
    'schemaVersion': 'trace-link-day3-corrections-verification-v1',
    'recordedAt': datetime.now(timezone.utc).isoformat(), 'implementationCommit': source_commit, 'pinnedMain': base,
    'originalReviewZipSha256': review_sha,
    'rootPython': {'tests': 174, 'failures': 0, 'skipped': 0},
    'mlPython': {'tests': 74, 'failures': 0, 'skipped': 0},
    'reactor': totals(root_reports), 'receiverUnit': totals(receiver_unit), 'receiverIntegration': totals(receiver_it),
    'dashboardUnit': {'tests': 181, 'failures': 0}, 'dashboardBrowser': {'tests': 13, 'failures': 0, 'skipped': 0},
    'dashboardBuild': 'PASS', 'apiGeneration': 'PASS_NO_GENERATED_DRIFT', 'compose': 'PASS_STRUCTURAL_PLACEHOLDERS_ONLY',
    'frozenPins': 'PASS_29_AND_INDEPENDENT_GOLDEN_USING_EXISTING_VALIDATOR',
    'unchangedMainMigrations': 26, 'historicalEvidenceFilesUnchangedInGit': len(historical),
    'freshDelivery': {'detections': 21, 'episodes': 3, 'kafkaDeliveriesAndCommittedOffsets': 42,
                      'evidenceRows': 21, 'auditRows': 21, 'recovered': 3,
                      'producerSha256': sha(producer_path.read_bytes()), 'receiverSha256': sha(receipt_path.read_bytes()),
                      'boundary': received['receiptBoundary'], 'incidentViewSource': received['incidentViewsSource']},
    'incidentViews': [{k: v for k, v in view.items() if k != 'latestDetection'} for view in received['incidentViews']],
    'suites': [item for _, item in root_reports + receiver_unit + receiver_it],
    'crossReview': {'migrations': 'Agent B: no blocking findings', 'receiver': 'Agent A: no blocking findings',
                    'sharedContractsAndBuild': 'Agent C: no blocking findings'},
    'status': 'CORRECTIONS_VERIFIED_LOCALLY_REVIEW_PENDING',
    'remainingGates': ['UPSTREAM_60_300_COMPATIBILITY', 'SIMULTANEOUS_END_TO_END_CAPACITY',
                       'ANALYST_WORKFLOW_CONTRACT', 'PERSONAL_SIGNOFFS', 'DEPLOYMENT_ACTIVATION_ACCEPTANCE'],
    'activation': 'DISABLED', 'longBenchmarkRerun': False, 'remotePushOrMerge': False,
}
write_json('verification.json', summary)
write_json('packed-artifacts.json', packed)
for name, meta in packed.items():
    raw = gzip.decompress((assets / name).read_bytes())
    assert sha(raw) == meta['uncompressedSha256'] and len(raw) == meta['uncompressedBytes']
print(json.dumps({key: summary[key] for key in ('implementationCommit', 'reactor', 'receiverUnit', 'receiverIntegration', 'freshDelivery')}))
