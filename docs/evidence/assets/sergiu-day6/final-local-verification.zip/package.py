from pathlib import Path
import json,hashlib,zipfile,xml.etree.ElementTree as E,subprocess
from datetime import datetime,timezone
root=Path.cwd();out=root/'tmp/day6-final';assets=root/'docs/evidence/assets/sergiu-day6'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
commands=json.loads((out/'java-commands.json').read_bytes())
assert [c['name'] for c in commands]==['docker-ready','processor-full','remaining-native-archive','fresh-java-python-feature-tests']
assert all(c['exitCode']==0 for c in commands)
def reports(folder):
 result={}
 for module in sorted(folder.iterdir()):
  counts={k:0 for k in ('tests','failures','errors','skipped')};skips=[]
  for p in module.glob('TEST-*.xml'):
   r=E.parse(p).getroot()
   for k in counts:counts[k]+=int(r.get(k,0))
   for case in r.findall('testcase'):
    skip=case.find('skipped')
    if skip is not None:skips.append(dict(className=case.get('classname'),method=case.get('name'),reason=skip.get('message','') or (skip.text or '').split('\n',1)[0]))
  result[module.name]=dict(counts=counts,skips=skips)
 return result
full=reports(out/'junit/full');archive=reports(out/'junit/archive')
assert all(not v['counts']['errors'] and not v['counts']['failures'] for v in full.values())
assert all(not v['counts']['errors'] and not v['counts']['failures'] for v in archive.values())
freeze=json.loads((assets/'detection-inputs.json').read_bytes());assert all(sha(root/p)==h for p,h in freeze['files'].items())
comparison=json.loads((root/'tmp/day6-resume-20261016/comparison.json').read_bytes());assert all(comparison.values())
study=json.loads((root/'tmp/day6-full-verification/evaluation/results.json').read_bytes())
files=sorted(p for p in out.rglob('*') if p.is_file());name='final-local-verification'
with zipfile.ZipFile(assets/(name+'.zip'),'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in files:z.write(p,p.relative_to(out).as_posix())
with (assets/(name+'-files.json')).open('x',encoding='utf-8') as f:json.dump({p.relative_to(out).as_posix():sha(p) for p in files},f,indent=2);f.write('\n')
summary=dict(generatedAt=datetime.now(timezone.utc).isoformat(),scope='LOCAL_DETECTION_PREPARATION',status='PASS_WITH_DOCUMENTED_EXTERNAL_SKIPS',productionSourceBase='d408f7472ab0a7193c235edb84ba2f282bd08c4e',toolingRevision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),detectionInputFileCount=len(freeze['files']),detectionInputManifestSha256=sha(assets/'detection-inputs.json'),rootPython=dict(tests=200,failures=0,errors=0,log='root-python-reviewed.log'),verifier=dict(tests=17,failures=0,errors=0,log='argv-green.log'),mlDiscovery=dict(tests=100,passed=99,skipped=1,reason='Fresh Java feature export absent before processor run; closed by final focused feature tests'),windowsByteReproduction='PASS',fourLanguageArithmetic=dict(cases=54,maxAbsoluteError=0),fullJava=full,archiveJava=archive,completedEarlierBootstrap=dict(tests=12,failures=0,errors=0,skipped=0,archive='interrupted-native-run.zip'),javaCommands=commands,heldOut=dict(sampleCounts=study['sampleCounts'],byteIdenticalRepeat=comparison,windowMetrics={m:v['windows'] for m,v in study['modes'].items()},episodeMetrics={m:None if v['episodes'] is None else {k:w for k,w in v['episodes'].items() if not isinstance(w,list)} for m,v in study['modes'].items()},timingBasis='synthetic event time; not deployed response latency'),unresolvedExternalChecks=['SMS_SHADOW_REPLAY_DIR not supplied','Legacy frozen V016 compatibility directory not supplied'],connectedRehearsals='NOT_RUN',commonReleaseManifest='NOT_SUPPLIED',humanAcceptance='PENDING',sharedReleaseApproval=False,currentBranchRemoteCi='NOT_RUN',failureHistory=['Initial repeat exceeded unchanged 250 ms scoring bound; serial unchanged-input repeat passed','Original full driver interrupted; no completed overall PASS receipt','Resumed attempt failed with Docker stopped: 369 setup errors','Native run interrupted after completed bootstrap suite; its remaining cases were resumed separately'])
with (assets/'verification-summary.json').open('x',encoding='utf-8') as f:json.dump(summary,f,indent=2);f.write('\n')
print(json.dumps({'fullJava':{k:v['counts'] for k,v in full.items()},'archiveJava':{k:v['counts'] for k,v in archive.items()},'filesArchived':len(files)},indent=2))
