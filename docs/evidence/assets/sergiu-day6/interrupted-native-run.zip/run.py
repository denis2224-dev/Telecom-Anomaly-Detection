import importlib.util,json,os,subprocess,sys,time,shutil
from pathlib import Path
from datetime import datetime,timezone
root=Path.cwd();out=root/'tmp/day6-docker-ready';env=dict(os.environ)
env['JAVA_HOME']=str((root/'../../tmp/jdk21-sergiu-days7-8/jdk-21.0.12.1+1').resolve());env['PATH']=env['JAVA_HOME']+'/bin;'+env['PATH'];records=[]
def run(name,args):
 start=datetime.now(timezone.utc).isoformat();tick=time.perf_counter()
 with (out/(name+'.log')).open('w',encoding='utf-8') as f:
  code=subprocess.run(args,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 records.append(dict(name=name,argv=args,startedAt=start,finishedAt=datetime.now(timezone.utc).isoformat(),elapsedSeconds=time.perf_counter()-tick,exitCode=code))
 (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,code,flush=True);return code
assert run('docker-ready',['docker','version','--format','{{.Server.Version}}'])==0
spec=importlib.util.spec_from_file_location('http',root/'scripts/verify-trace-link-ml-http.py');http=importlib.util.module_from_spec(spec);spec.loader.exec_module(http)
reference='D:/Univer/Anul2/Orange_intership/project/Trace_Link_Integration_Pack'
with http.server() as url:
 env['ML_SERVICE_URL']=url;started=time.time()
 run('processor-full',[str(root/'mvnw.cmd'),'-pl','services/processor','-am','verify','--batch-mode','--no-transfer-progress','-DtraceLink.referenceRoot='+reference,'-DtraceLink.projectionReferenceRoot='+reference,'-Dtrace.link.archive='+reference+'/data'])
 for report in (root/'services').glob('*/target/surefire-reports/TEST-*.xml'):
  if report.stat().st_mtime<started:continue
  dest=out/'junit'/report.parents[2].name/report.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(report,dest)
run('fresh-java-python-feature-tests',[sys.executable,'-m','unittest','discover','-s','services/ml-service/tests','-p','test_trace_link_features.py','-v'])
