from pathlib import Path
from datetime import datetime, timezone, timedelta
import json, re
OUT=Path(__file__).resolve().parent
ROOT=OUT.parent/'pr111-independent-lf-20261015'
v=json.loads((OUT/'verification/verification.json').read_text())
archive=json.loads((OUT/'archive-comparison.json').read_text())
candidate=json.loads((OUT/'candidate-comparison.json').read_text())
immut=json.loads((OUT/'immutability.json').read_text())
junit=json.loads((OUT/'junit-summary.json').read_text())
audit=json.loads((OUT/'frozen-audit.json').read_text())
records=[json.loads(line) for line in (OUT/'commands.jsonl').read_text().splitlines()]
success=v['status']=='PASS' and all(x['equal'] for k,x in archive.items() if k!='processor-export') and archive['processor-export']['byteEqual'] and not any(immut['changed'].values())
action='APPROVE' if success else 'REQUEST_CHANGES'
now=datetime.now(timezone.utc)
lines=['# Review independent — Sergiu, PR #111','',f'**Verdict formal: {action}.**',
    'Reviewer: **Codex (OpenAI), verificare automată independentă**, publicată prin contul GitHub conectat `itsjohnyoff`. Nu atribui execuția sau semnătura unei persoane.',
    f'Data: **15 octombrie 2026**. Receipt finalizat la `{now.isoformat()}` UTC / `{now.astimezone(timezone(timedelta(hours=3))).isoformat()}` Europe/Chisinau.',
    'PR: https://github.com/denis2224-dev/Telecom-Anomaly-Detection/pull/111',
    f'Source revision: `{audit["source"]}`. Git tree: `{audit["tree"]}`.',
    'Instrucțiuni de reproducere: exclusiv `docs/runbooks/detection-and-models.md` din această revizie. Codul și diff-ul au fost citite separat pentru review.',
    '', '## Rezultatul verificării', '',
    'Rebuild-ul Windows s-a făcut într-un director nou. Exportul Java pentru studiul arhivat a fost generat în această execuție, din input-ul arhivat, fără a folosi exportul publicat ca input al evaluării. Exportul publicat a fost folosit ulterior numai pentru comparație.',
    '', '| Verificare | Rezultat / dovadă |','|---|---|',
    '| Checkout izolat | Două worktree-uri detached la același SHA; al doilea creat direct cu LF, inițial fără modificări |',
    f'| Rebuild candidat Windows | {len(candidate)} fișiere identice cu pachetul aprobat; `candidate-comparison.json` |',
    '| Poarta Windows explicită | PASS; proces CLI curat, inventar complet și respingerea unei copii corupte; `windows-byte-gate.log` |',
    '| Export Java propriu pentru arhivă | PASS; identic byte-for-byte cu exportul publicat; `lf-fresh-archived-java-export.log` |',
    '| Rezultate / predicții / praguri arhivate | Toate identice byte-for-byte; `archive-comparison.json` |',
    f'| Verifier complet Windows | `{v["status"]}`, scope `{v["verificationScope"]}`, Windows gate `{v["windowsByteReproduction"]["status"]}`; `verification/verification.json` |',
    f'| Reactor Java și drill-uri Docker | {junit["totals"]["tests"]} raportate, {junit["totals"]["failures"]} failures, {junit["totals"]["errors"]} errors, {junit["totals"]["skipped"]} skips; detalii mai jos |',
    '| Model lipsă / corupt | PASS, 7 teste; lipsă, checksum/manifest, deserializare blocată, FALLBACK și readiness legacy păstrat; `model-failure-drills.log` |',
    '| HTTP real local | PASS, cele trei domenii și respingerea input-urilor adversariale; `http-diagnosis.log` |',
    '| Date lipsă | Export Java propriu și cele trei SELECT-uri documentate în PostgreSQL disposable, tranzacție READ ONLY; `missing-data-diagnosis.json`, `lf-read-only-data-diagnosis.log` |',
    f'| Imutabilitate | {immut["trackedCount"]} fișiere tracked și {immut["referenceCount"]} fișiere reference verificate înainte/după; modificări: {sum(len(x) for x in immut["changed"].values())} |',
    '| CI remote | Patru workflow-uri success la SHA-ul verificat; `remote-state.json`. CI nu înlocuiește acest receipt |',
    '', '## Mediu și pregătire', '',
    '- Windows 11, build 26100, AMD64; Windows PowerShell 5.1.26100.9168 (pwsh absent); CPU Intel64 Family 6 Model 140, 8 procesoare logice.',
    '- Python **3.13.9**, runtime local verificat; Python-ul implicit 3.13.7 nu a fost folosit pentru reproducere.',
    '- Java **Temurin 21.0.12.1+1**, Maven Wrapper **3.9.16**; detalii în `lf-java.log`, `lf-maven.log`.',
    '- Docker Desktop **4.66.1 (222799)**, client/engine **29.3.1**, Linux/amd64 pentru containere. Docker a fost pornit pentru resursele Testcontainers.',
    '- Pinned requirements instalate în venv-ul izolat. Inventar complet, inclusiv dependențele tranzitive: `lf-dependencies.log`.',
    '- Reference pack: `C:/OrangeSystems/task/Trace_Link_Integration_Pack`; verificarea celor 29 de fișiere V2/reference și a fixture-ului independent a trecut.',
    '- Workspace final: `C:/OrangeSystems/Program/pr111-independent-lf-20261015`. Venv-ul izolat din primul worktree a fost reutilizat în al doilea, cu aceleași versiuni; nu provine din venv-ul autorului.',
    '- Override-uri exclusiv pentru tooling: `JAVA_HOME=C:/Program Files/Eclipse Adoptium/jdk-21.0.12.101-hotspot`; `MAVEN_OPTS=-Dmaven.repo.local=C:/OrangeSystems/Program/.tools/m2`; `PYTHONPATH=<workspace>/services/ml-service`.',
    '', '```powershell',
    'git -C Telecom-Anomaly-Detection fetch origin refs/pull/111/head',
    'git -C Telecom-Anomaly-Detection worktree add --detach C:/OrangeSystems/Program/pr111-independent-20261015 5d5a9d596beed8c47e72d5fc3e2b03c8fc8809b7',
    '& C:/OrangeSystems/Program/sergiu-day4-review-evidence-20261014/python-runtime/cpython-3.13.9-windows-x86_64-none/python.exe -m venv .venv',
    '.venv/Scripts/python.exe -m pip install -r requirements-dev.txt -r services/ml-service/requirements-ml.txt',
    'git -c core.autocrlf=false -C Telecom-Anomaly-Detection worktree add --detach C:/OrangeSystems/Program/pr111-independent-lf-20261015 5d5a9d596beed8c47e72d5fc3e2b03c8fc8809b7',
    '```',
    '', 'Fetch, ambele worktree-uri, crearea venv-ului și instalarea cu acces de rețea au ieșit cu 0. Comenzile de reproducere și exit-urile sunt în anexele de mai jos și în `commands.jsonl`; helper-ul `run_receipt.py` captează argv, cwd, UTC, durată, exit și log fără a schimba sursele.',
    '', '## Comparație SHA-256', '', '| Artefact | SHA-256 publicat = SHA-256 proaspăt |','|---|---|']
for name,row in archive.items():
    lines.append(f'| {name} | `{row.get("expected",row.get("archivedSha256"))}` |')
lines += ['', 'Praguri neschimbate: TRANSPORT **0.95**, ROAMING **0.95**, MOBILE_DATA **0.90**; `testUsed=false`. Studiu: 280 grupuri / 3.360 ferestre, 1.680 ferestre test. Detectorul determinist: 65 TP / 0 FP / 0 FN la episoade; fără baseline: 20 TP / 0 FP / 45 FN. ML shadow rămâne opțional și nu are politică de episoade/cauze.',
    '', '| Input arhivat | SHA-256 |','|---|---|']
for p,h in audit['studyPins'].items():lines.append(f'| {Path(p).name} | `{h}` |')
lines += ['', 'Pachetul candidat, modelele existente, politicile, baseline-urile și fixture-urile nu diferă față de baza PR. Arhiva Day 5 originală nu diferă între commit-ul de arhivare `be68245` și head-ul corectat. Snapshot-urile complete înainte/după sunt păstrate; nu s-au regenerat artefacte aprobate în loc, nu s-au modificat truth/protocol/seeds și nu s-au ajustat praguri.',
    '', '## Findings, eșecuri și limite', '',
    '1. **P3 — checkout Windows cu CRLF.** Prima evaluare a arhivei a eșuat cu exit 1: `Source pin mismatch: contracts/README.md`. 206 pin-uri diferite erau exclusiv conversii CRLF/LF. Runbook-ul cere LF, dar nu oferă comanda de checkout. Un worktree nou creat cu `git -c core.autocrlf=false ... worktree add` reproduce pin-urile și raportul fără modificarea input-urilor. Recomandare: includeți această comandă în runbook. `archived-evaluation.log` și `crlf-pin-diagnosis.json` păstrează eșecul și diagnosticul.',
    '2. **P3 — diagnoza manuală operațională este incomplet descrisă.** Runbook-ul oferă SELECT-urile și cere restart normal, dar nu dă comenzi de conectare la o bază locală disposable și de stop/start worker. Am executat cele trei SELECT-uri în containerul PostgreSQL al acestei verificări, într-o tranzacție READ ONLY: pending source=0, pending shadow=0, nicio lease pending la acel snapshot. Nu am interogat o bază partajată. Restart-ul este verificat prin drill-ul automat documentat; un worker operațional live nu a fost repornit. Recomandare: adăugați comenzile locale și rezultatele așteptate în runbook.',
    '3. **Pregătire mediu.** Prima instalare pip a eșuat cu exit 1 din cauza restricției de rețea WinError 10013; reluarea autorizată a trecut. Docker a raportat inițial pipe absent / exit 1, apoi client și server au fost verificați după pornire. Primul `maven -version` prin helper a eșuat cu exit 1 deoarece helper-ul a transmis `./mvnw.cmd` către Windows subprocess; calea absolută a remediat harness-ul, fără schimbări în repository. Log-urile inițiale sunt păstrate.',
    '4. **Comenzi auxiliare de inspecție.** Două încercări Python inline pentru auditul hash-urilor au ieșit cu SyntaxError/exit 1 din cauza quoting-ului PowerShell; auditul a fost efectuat ulterior prin fișiere Python, exit 0. Acestea sunt erori ale harness-ului de review, nu ale produsului.',
    '5. **Linux nativ: NOT_RUN în acest receipt.** Ramura Linux și respingerea porții Windows sunt confirmate prin code review și regresiile documentate din suita root; acestea folosesc simularea platformei. Nu pretind că am rulat verifier-ul complet într-un Linux separat.',
    '6. **Acceptare:** `secondPersonReproduction=PENDING` și `sharedReleaseApproval=false` rămân neschimbate în manifest. Acest receipt identifică explicit un reviewer automat; nu este o semnătură umană. Review-ul GitHub privește codul și dovezile tehnice măsurate. Receipt-ul trebuie revizuit de persoana responsabilă înaintea acceptării Day 5. PR-ul rămâne draft; fără merge, promovare model sau activare.',
    '', 'Date lipsă: exemplele proaspete păstrează `quality=MISSING`, `coverage=0`, `observedAt=null`, populație/primitives indisponibile și verdict `UNKNOWN`. Golurile în impairment/recovery nu sunt convertite în sănătate sau recovery. Exemplul de low volume rămâne ineligibil/UNKNOWN. Evaluarea este `EVENT_TIME_REPLAY`; nu dovedește freshness live sau capacitate de producție.',
    '', '## Toate skip-urile', '',
    'Prima suită ML: 100 teste raportate, 99 trecute, un skip: `test_fresh_java_exports_match_independent_python`, deoarece exportul `TraceLinkFeaturesTest` nu exista încă. Parity-ul Java/Python ulterior are propriul rezultat și log în verifier. Nu adunăm invocările suprapuse.',
    '', '| Suită / test | Motiv skip |','|---|---|']
for suite in junit['suites']:
    for skip in suite['skips']:
        reason=(skip['reason'] or skip['detail'] or 'nespecificat').splitlines()[0].replace('|','/')
        if skip['name'] in ('livePackagedModelEnrichesRecoveredSmsEpisode','livePackagedModelEnrichesRecoveredVoiceEpisode'):
            reason='ML_SERVICE_URL absent (confirmat în condiția assumeTrue din test)'
        lines.append(f'| `{skip["classname"]}.{skip["name"]}` | {reason} |')
for log in sorted((OUT/'verification').glob('*python.log')):
    for text in log.read_text(errors='replace').splitlines():
        if ' ... skipped ' in text:lines.append(f'| `{log.name}` | {text.replace("|","/")} |')
lines += ['', 'Detalii pentru fiecare suită Java și fiecare skip: `junit-summary.json`, XML-urile și log-urile originale. Testele opționale neexecutate nu sunt revendicate ca PASS.',
    '', '## Platform correction — code review', '',
    '- `sys.platform == win32` selectează `WINDOWS_FULL`; Linux selectează `PORTABLE_RUNTIME` și `windowsByteReproduction.status=NOT_RUN`.',
    '- Pe Windows, poarta CLI separată compară inventarul și fiecare SHA; coruperea copiei este respinsă. Un eșec produce `INCOMPLETE`, exit nenul și log-uri păstrate.',
    '- Succesul tehnic pe ambele platforme păstrează `secondPersonReproduction=PENDING` / `sharedReleaseApproval=false`. Cele opt regresii de boundary/verifier verifică aceste ramuri și prerequisite lipsă.',
    '- CI păstrează dependențele Windows byte reproduction → Linux model evaluation → processor evaluation → Day 5 evaluation. Niciun rezultat de workflow nu acordă automat acceptarea independentă.',
    '', '## Comenzi executate, exit-uri și log-uri', '',
    'Forma din `commands.jsonl` este argv-ul exact. Mai jos este echivalentul PowerShell; fiecare bloc indică directorul curent. Exit-urile subprocess-urilor interne sunt în manifestul verifier-ului, nu sunt ascunse de exit-ul helper-ului.', '']
def ps(cmd):return '& '+' '.join("'"+str(x).replace("'","''")+"'" for x in cmd)
for r in records:
    lines += [f'### {r["name"]} — exit {r["exitCode"]}', '',f'Cwd: `{r["cwd"]}`. UTC `{r["startedAt"]}` → `{r["finishedAt"]}`. Log: `{r["name"]}.log`.', '', '```powershell',ps(r['command']),'```','']
lines += ['### Subcomenzile verifier-ului documentat', '', '| Etapă | Exit | Log |','|---|---:|---|']
for r in v['commands']:lines.append(f'| {r["name"]} | {r["exitCode"]} | `verification/{r["name"]}.log` |')
for r in v['commands']:
    if 'command' in r:lines += ['',f'`{r["name"]}`:', '', '```powershell',ps(r['command']),'```']
lines += ['', '## Integritatea bundle-ului', '',
    '`sha256.json` conține hash-urile log-urilor, manifestelor, XML-urilor și output-urilor; `fresh-archived-java-export.json.gz` conține exportul propriu. Comparația exportului folosește bytes JSON decomprimați, nu header-ul gzip. `review-evidence.zip` împachetează receipt-ul și dovezile fără venv, cache Maven sau credențiale.',
    '', 'Review-ul formal și starea finală a PR-ului sunt în `github-review-result.json` / `remote-final-state.json` după publicare. Nu s-a modificat branch-ul PR-ului.', '']
backlog_path=OUT/'verification/day5-backlog-drill.json'
if backlog_path.exists():
    backlog=json.loads(backlog_path.read_text())
    lines += ['Drill backlog/restart (PostgreSQL real):', '', '```json',json.dumps(backlog,indent=2),'```','']
lines += ['Pregătire suplimentară: în primul worktree, `git -c core.autocrlf=false checkout-index --all --force` a ieșit cu 0, dar nu a rescris fișierele CRLF deja existente. Worktree-ul LF a fost creat separat, fără conversia sau resigilarea input-urilor aprobate.', '']
for name in ('root-python.log','ml-python.log'):
    log_text=(OUT/'verification'/name).read_text(errors='replace')
    summary=[x for x in log_text.splitlines() if x.startswith('Ran ') or x.startswith('OK') or x.startswith('FAILED')]
    lines += [f'Invocarea finală `{name}`: '+ '; '.join(summary), '']
if v['status']!='PASS':
    lines += ['**Eșecuri aplicabile ale verifier-ului:**', '']
    for r in v['commands']:
        if r['exitCode']!=0:lines.append(f'- `{r["name"]}`: exit {r["exitCode"]}; vedeți log-ul și remediați cauza fără modificarea input-urilor înghețate.')
cli_result=OUT/'github-review-cli-result.json'
if cli_result.exists():
    published=json.loads(cli_result.read_text(encoding='utf-8-sig'))
    lines[3:3]=[f'Review publicat: [{published["state"]}]({published["html_url"]}), ID `{published["id"]}`, commit `{published["commit_id"]}`.', '']
    lines += ['Publicare review: conectorul GitHub a returnat HTTP 403 / Resource not accessible by integration; încercarea este păstrată în `github-review-result.json`. Fallback-ul GitHub CLI autentificat cu același cont `itsjohnyoff` a ieșit cu 0 și a publicat review-ul APPROVED, ID 5533312847. PR-ul a fost reverificat ulterior: draft=true, merged=false, head neschimbat.', '',
        '```powershell', 'gh api user --jq .login', 'gh api repos/denis2224-dev/Telecom-Anomaly-Detection/pulls/111/reviews --method POST --input C:/OrangeSystems/Program/pr111-independent-evidence-20261015/review-request.json', '```', '']
(OUT/'review-sergiu-pr111.md').write_text('\n'.join(lines),encoding='utf-8')
(OUT/'review-action.txt').write_text(action)
body=f'''Independent Windows reproduction and code review of `{audit['source']}` on 15 October 2026.

Reviewer: Codex (OpenAI automated independent reviewer), using the connected reviewer account. Reproduction instructions were taken only from `docs/runbooks/detection-and-models.md`.

Technical verification: **{v['status']}**. Windows 11 / PowerShell 5.1.26100.9168, Python 3.13.9, Temurin Java 21.0.12.1, Maven 3.9.16, Docker Desktop 4.66.1 / Engine 29.3.1, approved reference pack verified.

- Rebuilt the candidate into a new directory: all {len(candidate)} files byte-identical. Explicit clean-process Windows gate passed, including corrupted-copy rejection.
- Generated my own fresh Java export from the archived study. Its uncompressed bytes match the published export; evaluated using this newly generated export, not the archived export.
- Results, predictions and thresholds match the published archive byte-for-byte. Thresholds remain TRANSPORT=0.95, ROAMING=0.95, MOBILE_DATA=0.90.
- Ran the documented full verifier, missing/corrupt-model failure suite (7 tests), real local HTTP checks, and disposable PostgreSQL/Kafka regression/drills. Also ran all three documented diagnostic SELECTs in a read-only transaction against the review's disposable PostgreSQL container.
- Java reactor: {junit['totals']['tests']} tests reported, {junit['totals']['failures']} failures, {junit['totals']['errors']} errors, {junit['totals']['skipped']} conditional skips. Root Python: 183 reported / 182 passed / 1 pwsh-dependent Day 1 skip. ML: 100 reported / 99 passed / 1 pre-export parity skip; the subsequent explicit fresh-Java parity gate is recorded separately. All skips and raw logs are retained in the receipt.
- {immut['trackedCount']} tracked files and {immut['referenceCount']} reference-pack files were hash-checked before/after, with no changes. Frozen models/policies/fixtures are unchanged from the PR base; the original Day 5 archive is unchanged throughout the platform correction.

SHA-256 (published = fresh):

| File | SHA-256 |
|---|---|
'''
for name,row in archive.items():body+=f"| {name} | `{row.get('expected',row.get('archivedSha256'))}` |\n"
body+='''
Platform correction reviewed: Linux reports `PORTABLE_RUNTIME` / Windows byte `NOT_RUN`; Windows requires the explicit gate; applicable failures propagate `INCOMPLETE` and nonzero exit. Eight verifier/boundary regressions passed. Native Linux full reproduction was not rerun in this receipt. Both scopes retain `secondPersonReproduction=PENDING` and `sharedReleaseApproval=false`; CI preserves Windows → Linux model → processor → Day 5 dependencies.

Nonblocking runbook findings: (1) provide the explicit LF checkout command (`git -c core.autocrlf=false ... worktree add`); the initial default-CRLF archive evaluation failed at a source pin and was retained before repeating in a fresh canonical LF checkout; (2) document disposable database connection and normal worker stop/start commands alongside the diagnostic SQL. The SQL and scripted restart/fencing drill were verified independently of a shared/live deployment.

Full Romanian receipt: `review-sergiu-pr111.md`; raw commands/UTC/exits, hashes, XML, every failure/skip and outputs are preserved in the local evidence bundle for handoff. No approved artifact/input was overwritten or resealed, and no threshold was tuned.

This review covers the measured technical reproduction and code. It does not impersonate a human signer or automatically grant Day 5/shared release acceptance. The responsible person must review the receipt. Keep the PR **draft**; no merge or activation.
'''
if action=='REQUEST_CHANGES':
    body+='\nRequired applicable failures must be resolved and the documented checks rerun without altering frozen inputs:\n'
    for r in v['commands']:
        if r['exitCode']!=0:body+=f"- `{r['name']}`: exit {r['exitCode']}; inspect its retained log.\n"
(OUT/'github-review-body.md').write_text(body,encoding='utf-8')
print(action)
