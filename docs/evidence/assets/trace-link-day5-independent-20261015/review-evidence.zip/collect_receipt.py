from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json, shutil, xml.etree.ElementTree as ET, gzip, zipfile
OUT=Path(__file__).resolve().parent
ROOT=OUT.parent/'pr111-independent-lf-20261015'
OLD=OUT.parent/'pr111-independent-20261015'
VERIFY=ROOT/'tmp/day5-independent-verification'
def digest(p):return sha256(p.read_bytes()).hexdigest()
if not (VERIFY/'verification.json').exists():raise SystemExit('verifier still pending')
dest=OUT/'verification'
shutil.copytree(VERIFY,dest,dirs_exist_ok=True)
shutil.copytree(ROOT/'tmp/day5-independent-archived-results',OUT/'archived-results',dirs_exist_ok=True)
shutil.copytree(OLD/'tmp/day5-independent-candidate',OUT/'rebuilt-candidate',dirs_exist_ok=True)
export=ROOT/'tmp/day5-independent-archived-processor.json'
(OUT/'fresh-archived-java-export.json.gz').write_bytes(gzip.compress(export.read_bytes(),mtime=0))
shutil.copy2(OLD/'tmp/day4-http-server.log',OUT/'http-diagnosis-server.log')
shutil.copy2(ROOT/'tmp/day4-http-server.log',OUT/'verification-http-server.log')
inventory=[]
for path in (dest/'junit').rglob('TEST-*.xml'):
    suite=ET.parse(path).getroot()
    skips=[dict(classname=t.get('classname'),name=t.get('name'),reason=t.find('skipped').get('message'),
                detail=t.find('skipped').text) for t in suite.findall('testcase') if t.find('skipped') is not None]
    inventory.append(dict(file=path.relative_to(OUT).as_posix(),suite=suite.get('name'),
        tests=int(suite.get('tests',0)),failures=int(suite.get('failures',0)),errors=int(suite.get('errors',0)),
        skipped=int(suite.get('skipped',0)),skips=skips))
totals={key:sum(s[key] for s in inventory) for key in ('tests','failures','errors','skipped')}
(OUT/'junit-summary.json').write_text(json.dumps(dict(totals=totals,suites=inventory),indent=2)+'\n')
before=json.loads((OUT/'lf-before.json').read_text()); after=json.loads((OUT/'lf-after.json').read_text())
changed={section:[p for p,h in before[section].items() if after[section].get(p)!=h] for section in before}
(OUT/'immutability.json').write_text(json.dumps(dict(checkedAt=datetime.now(timezone.utc).isoformat(),
    trackedCount=len(before['tracked']),referenceCount=len(before['reference']),changed=changed),indent=2)+'\n')
hashes={p.relative_to(OUT).as_posix():digest(p) for p in OUT.rglob('*') if p.is_file() and p.name not in ('sha256.json','review-evidence.zip')}
(OUT/'sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
print(json.dumps(dict(junit=totals,changed=changed,files=len(hashes))))
