import json, os, platform, subprocess, sys, time
from datetime import datetime, timezone
from pathlib import Path
from hashlib import sha256

ROOT=Path('C:/OrangeSystems/Program/pr111-independent-lf-20261015')
OUT=ROOT.parent/'pr111-independent-evidence-20261015'
PY=str(ROOT.parent/'pr111-independent-20261015/.venv/Scripts/python.exe')
REF='C:/OrangeSystems/task/Trace_Link_Integration_Pack'
env=dict(os.environ)
env['JAVA_HOME']='C:/Program Files/Eclipse Adoptium/jdk-21.0.12.101-hotspot'
env['MAVEN_OPTS']='-Dmaven.repo.local=C:/OrangeSystems/Program/.tools/m2'
env['PYTHONPATH']=str(ROOT/'services/ml-service')
records=OUT/'commands.jsonl'

def run(name,command):
    name='lf-'+name
    if command[0]=='./mvnw.cmd': command[0]=str(ROOT/'mvnw.cmd')
    tick=time.monotonic(); start=datetime.now(timezone.utc).isoformat()
    with (OUT/(name+'.log')).open('w',encoding='utf-8') as log:
        try: code=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
        except OSError as e: log.write(str(e)); code=127
    receipt=dict(name=name,command=command,cwd=str(ROOT),startedAt=start,
        finishedAt=datetime.now(timezone.utc).isoformat(),elapsedSeconds=time.monotonic()-tick,exitCode=code,
        environmentOverrides={k:env[k] for k in ('JAVA_HOME','MAVEN_OPTS','PYTHONPATH')})
    with records.open('a',encoding='utf-8') as log: log.write(json.dumps(receipt)+'\n')
    print(name,code,flush=True)
    return code

def snapshot(name):
    name='lf-'+name
    tracked=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
    files={p:sha256((ROOT/p).read_bytes()).hexdigest() for p in tracked if p and (ROOT/p).is_file()}
    refs={p.relative_to(Path(REF)).as_posix():sha256(p.read_bytes()).hexdigest() for p in Path(REF).rglob('*') if p.is_file()}
    (OUT/(name+'.json')).write_text(json.dumps(dict(tracked=files,reference=refs),indent=2)+'\n')

stage=sys.argv[1]
if stage=='baseline':
    snapshot('before')
    for name,cmd in [('revision',['git','rev-parse','HEAD']),('tree',['git','rev-parse','HEAD^{tree}']),
        ('initial-status',['git','-c','core.autocrlf=false','status','--porcelain']),('python',[PY,'-VV']),
        ('java',['java','-version']),('maven',['./mvnw.cmd','-version']),('docker',['docker','version']),
        ('dependencies',[PY,'-m','pip','freeze']),('pins',[PY,'scripts/verify-trace-link-pins.py','--reference-root',REF])]:run(name,cmd)
    (OUT/'host.json').write_text(json.dumps(dict(reviewer='Codex (OpenAI automated independent reviewer)',
        utc=datetime.now(timezone.utc).isoformat(),platform=platform.platform(),machine=platform.machine(),cpu=platform.processor(),cpus=os.cpu_count()),indent=2))
elif stage=='candidate':
    run('rebuild',[PY,'services/ml-service/training/trace_link_candidate.py','--output','tmp/day5-independent-candidate'])
    run('windows-byte-gate',[PY,'services/ml-service/tests/windows_candidate_reproduction.py','-v'])
    run('ml-discovery',[PY,'-m','unittest','discover','-s','services/ml-service/tests','-v'])
elif stage=='archive':
    study=ROOT/'docs/evidence/assets/trace-link-day5-20261015/study'
    export=ROOT/'tmp/day5-independent-archived-processor.json'
    code=run('fresh-archived-java-export',['./mvnw.cmd','-pl','services/processor','-am','test','-Dtest=TraceLinkStudyExportTest',
        '-Dsurefire.failIfNoSpecifiedTests=false','-DtraceLink.study.inputs='+str(study/'inputs.json.gz'),
        '-DtraceLink.study.output='+str(export),'--batch-mode','--no-transfer-progress'])
    if code==0:
        run('archived-evaluation',[PY,'services/ml-service/training/trace_link_evaluation.py','--dataset',str(study),
            '--protocol',str(study/'protocol.json'),'--processor-export',str(export),'--candidate','services/ml-service/candidate-models/trace-link-shadow-v1',
            '--output','tmp/day5-independent-archived-results'])
elif stage=='verify':
    run('full-verifier',[PY,'scripts/verify-trace-link-day5.py','--output','tmp/day5-independent-verification','--reference-root',REF])
elif stage=='diagnose':
    run('model-load',[PY,'-c','from app.inference.trace_link_scoring import load; load()'])
    run('model-failure-drills',[PY,'-m','unittest','discover','-s','services/ml-service/tests','-p','test_trace_link_failure_modes.py','-v'])
    run('http-diagnosis',[PY,'scripts/verify-trace-link-ml-http.py'])
elif stage=='final':
    snapshot('after')
    run('final-status',['git','-c','core.autocrlf=false','status','--porcelain'])
elif stage=='sql':
    sql="""BEGIN READ ONLY;
SELECT count(*) AS pending, min(w.created_at) AS oldest_pending_source
FROM app.trace_link_job j JOIN app.trace_link_window w USING(window_id)
WHERE j.completed_at IS NULL;
SELECT count(*) AS pending, min(e.evaluated_at) AS oldest_pending_evaluation
FROM app.trace_link_shadow_job j JOIN app.trace_link_evaluated_window e USING(window_id)
WHERE j.completed_at IS NULL;
SELECT lease_until, completed_at FROM app.trace_link_shadow_job
WHERE completed_at IS NULL ORDER BY lease_until NULLS FIRST LIMIT 20;
ROLLBACK;"""
    run('read-only-data-diagnosis',['docker','exec','1394556f2840','psql','-U','processing_app','-d','processing_db','-v','ON_ERROR_STOP=1','-c',sql])
