from pathlib import Path
from hashlib import sha256
import json, zipfile
OUT=Path(__file__).resolve().parent
excluded={'sha256.json','review-evidence.zip','review-evidence.zip.sha256','bundle-summary.json'}
files=sorted(p for p in OUT.rglob('*') if p.is_file() and p.name not in excluded)
hashes={p.relative_to(OUT).as_posix():sha256(p.read_bytes()).hexdigest() for p in files}
(OUT/'sha256.json').write_text(json.dumps(hashes,indent=2)+'\n',encoding='utf-8')
archive=OUT/'review-evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files+[OUT/'sha256.json']:z.write(p,p.relative_to(OUT).as_posix())
with zipfile.ZipFile(archive) as z:
    failed=z.testzip()
    if failed:raise RuntimeError('ZIP integrity failure: '+failed)
digest=sha256(archive.read_bytes()).hexdigest()
(OUT/'review-evidence.zip.sha256').write_text(digest+'  review-evidence.zip\n',encoding='utf-8')
summary=dict(files=len(files)+1,zipBytes=archive.stat().st_size,sha256=digest,zipIntegrity='PASS',
    reportSha256=hashes['review-sergiu-pr111.md'],review='https://github.com/denis2224-dev/Telecom-Anomaly-Detection/pull/111#pullrequestreview-5533312847')
(OUT/'bundle-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary))
