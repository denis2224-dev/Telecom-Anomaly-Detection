import json, subprocess
from pathlib import Path
from hashlib import sha256
OUT=Path(__file__).resolve().parent
ROOT=OUT.parent/'pr111-independent-lf-20261015'
archive=ROOT/'docs/evidence/assets/trace-link-day5-20261015'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def digest(p):return sha256(p.read_bytes()).hexdigest()
audit=dict(source=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),
    frozenChangesAgainstBase=git('diff','--name-only','ce35fec7ecf0b99fcfd4df1dd9516aaa588c8a7f','HEAD','--',
        'services/ml-service/candidate-models','services/ml-service/models','contracts/policies','contracts/baselines','contracts/fixtures'),
    originalArchiveChangesDuringCorrection=git('diff','--name-only','be68245','HEAD','--','docs/evidence/assets/trace-link-day5-20261015'),
    studyPins={str(p.relative_to(ROOT)):digest(p) for p in (archive/'study').iterdir() if p.is_file()})
audit['thresholds']=json.loads((archive/'results/thresholds.json').read_bytes())
(OUT/'frozen-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
export=ROOT/'tmp/day5-independent-archived-processor.json'
if export.exists():
    rows=json.loads(export.read_bytes())['rows']
    truth=json.loads((archive/'study/truth.json').read_bytes())
    groups={g['group']:g for g in truth}
    selected=[]
    for category,slot in [('missing_source',3),('gap_during_impairment',5),('gap_during_recovery',7),('low_volume',3)]:
        row=next(r for r in rows if r['mode']=='deterministic' and r['slot']==slot and groups[r['group']]['category']==category and groups[r['group']]['split']=='test')
        c=row['context']
        selected.append(dict(category=category,slot=slot,group=row['group'],domain=c['domain'],scope=c['scope'],
            window=c['window'],evaluatedAt=c['evaluatedAt'],evidence=c['evidence'],baselines=c['baselines'],evaluations=row['evaluations']))
    diagnosis=dict(scope='Fresh offline Java export plus documented PostgreSQL regression; not a live operational database acceptance',
        examples=selected,manualOperationalSql='PASS: all three documented SELECT queries ran with BEGIN READ ONLY in disposable Testcontainers PostgreSQL 1394556f2840; pending source=0, pending shadow=0, no pending leases at this snapshot; no shared database queried',
        workerRestartScope='Documented automated PostgreSQL backlog/restart/fencing drill; no live operational worker restarted')
    (OUT/'missing-data-diagnosis.json').write_text(json.dumps(diagnosis,indent=2)+'\n')
print('inspection written')
