from pathlib import Path
from hashlib import sha256
import gzip, json, subprocess
OUT=Path(__file__).resolve().parent
ROOT=OUT.parent/'pr111-independent-lf-20261015'
OLD=OUT.parent/'pr111-independent-20261015'
archive=ROOT/'docs/evidence/assets/trace-link-day5-20261015'
def h(p):return sha256(p.read_bytes()).hexdigest()
manifest=json.loads((archive/'study/manifest.json').read_bytes())
diagnosis=[]
for p,expected in manifest['sourcePins'].items():
    old=(OLD/p).read_bytes(); new=(ROOT/p).read_bytes()
    if sha256(old).hexdigest()!=expected:
        diagnosis.append(dict(path=p,expected=expected,crlfHash=sha256(old).hexdigest(),
            lfHash=sha256(new).hexdigest(),newlineOnly=old.replace(b'\r\n',b'\n')==new,
            newMatches=sha256(new).hexdigest()==expected))
(OUT/'crlf-pin-diagnosis.json').write_text(json.dumps(diagnosis,indent=2)+'\n')
candidate=ROOT/'services/ml-service/candidate-models/trace-link-shadow-v1'
rebuilt=OLD/'tmp/day5-independent-candidate'
comparisons={}
for p in candidate.iterdir():
    if p.is_file():comparisons[p.name]=dict(expected=h(p),actual=h(rebuilt/p.name),equal=p.read_bytes()==(rebuilt/p.name).read_bytes())
(OUT/'candidate-comparison.json').write_text(json.dumps(comparisons,indent=2)+'\n')
export=ROOT/'tmp/day5-independent-archived-processor.json'
if export.exists():
    archived=gzip.decompress((archive/'processor-export.json.gz').read_bytes())
    fresh=export.read_bytes()
    comparisons={'processor-export':dict(archivedSha256=sha256(archived).hexdigest(),freshSha256=h(export),
        byteEqual=archived==fresh,jsonEqual=json.loads(archived)==json.loads(fresh))}
    for name in ('results.json','predictions.json','thresholds.json'):
        expected=archive/'results'/name; actual=ROOT/'tmp/day5-independent-archived-results'/name
        comparisons[name]=dict(expected=h(expected),actual=h(actual) if actual.exists() else None,
            equal=actual.exists() and expected.read_bytes()==actual.read_bytes())
    (OUT/'archive-comparison.json').write_text(json.dumps(comparisons,indent=2)+'\n')
print('comparison files written')
