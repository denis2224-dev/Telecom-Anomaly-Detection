# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: resource-bounds.spec.ts >> Browser resource bounds >> service: sustained hints remain responsive with bounded REST refreshes
- Location: tests/e2e/specs/resource-bounds.spec.ts:171:70

# Error details

```
Error: page.evaluate: Execution context was destroyed, most likely because of a navigation.
```

# Test source

```ts
  93  |       return route.fulfill({ status: 400, json: { code: 'INVALID_RANGE' } });
  94  |     }
  95  |     const count = Math.max(0, Math.min(size, total - number * size));
  96  |     return route.fulfill({ json: {
  97  |       items: Array.from({ length: count }, (_, index) => windowAt(from + (number * size + index) * 60_000)),
  98  |       total, page: number, size, observedAt: new Date(latestEnd).toISOString(),
  99  |     } });
  100 |   });
  101 |   await page.route('**/api/incidents?**', route => {
  102 |     incidentReads++;
  103 |     const query = new URL(route.request().url()).searchParams;
  104 |     const number = Number(query.get('page') ?? 0), size = Number(query.get('size') ?? 20);
  105 |     lastIncidentPage = number;
  106 |     return route.fulfill({ json: {
  107 |       items: Array.from({ length: Math.max(0, Math.min(size, 1000 - number * size)) },
  108 |         (_, index) => incident(number * size + index)),
  109 |       total: 1000, page: number, size,
  110 |     } });
  111 |   });
  112 |   await page.route('**/api/incidents/resource-incident-*', route => {
  113 |     detailReads++;
  114 |     const index = Number(new URL(route.request().url()).pathname.split('-').at(-1));
  115 |     return route.fulfill({ json: incident(index) });
  116 |   });
  117 |   await page.route('**/api/incidents/*/timeline?**', route => route.fulfill({ json: {
  118 |     items: [], total: 0, page: 0, size: 100,
  119 |   } }));
  120 |   await page.route('**/api/incidents/*/detections?**', route => {
  121 |     const query = new URL(route.request().url()).searchParams;
  122 |     const number = Number(query.get('page') ?? 0), size = Number(query.get('size') ?? 20);
  123 |     lastEvidencePage = number;
  124 |     return route.fulfill({ json: {
  125 |       items: Array.from({ length: Math.max(0, Math.min(size, 1000 - number * size)) }, (_, index) => ({
  126 |         ...voiceIncidents[0].latestDetection,
  127 |         detectionId: `resource-detection-${number * size + index}`,
  128 |         sequence: number * size + index + 1,
  129 |       })), total: 1000, page: number, size,
  130 |     } });
  131 |   });
  132 |   return {
  133 |     advance: () => { latestEnd += 60_000; },
  134 |     serviceReads: () => serviceReads,
  135 |     detailReads: () => detailReads,
  136 |     delay: (ms: number) => { responseDelayMs = ms; },
  137 |     reads: () => kpiReads,
  138 |     incidentReads: () => incidentReads,
  139 |     incidentPage: () => lastIncidentPage,
  140 |     evidencePage: () => lastEvidencePage,
  141 |   };
  142 | }
  143 | 
  144 | async function paint(page: Page) {
  145 |   await page.evaluate(() => new Promise<void>(resolve =>
  146 |     requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  147 | }
  148 | 
  149 | async function navigateToLoginAndExpectCleanup(page: Page) {
  150 |   const retained = await page.evaluateHandle(() => ({
  151 |     state: (window as any).__resource, stream: (window as any).__resource.stream,
  152 |   }));
  153 |   expect(await retained.evaluate(({ state }) => state.active)).toBe(1);
  154 |   // Stay in the same document: goto resets the mock, then the authenticated
  155 |   // session redirects from /login to /dashboard and opens a new stream.
  156 |   await page.evaluate(() => {
  157 |     history.pushState(null, '', '/login');
  158 |     window.dispatchEvent(new PopStateEvent('popstate'));
  159 |   });
  160 |   await expect(page.getByRole('heading', { name: 'Sign in to investigate service issues' })).toBeVisible();
  161 |   await expect(page).toHaveURL(/\/login$/);
  162 |   expect(await retained.evaluate(({ state }) => state === (window as any).__resource)).toBe(true);
  163 |   await expect.poll(() => retained.evaluate(({ state }) => state.active)).toBe(0);
  164 |   expect(await retained.evaluate(({ stream }) => stream.closed)).toBe(true);
  165 |   await retained.dispose();
  166 | }
  167 | 
  168 | test.describe('Browser resource bounds', () => {
  169 |   test.skip(!!process.env.E2E_REAL_LOGIN, 'Controlled dataset; use real login separately for backend evidence');
  170 | 
  171 |   for (const screen of ['overview', 'service', 'investigation']) test(`${screen}: sustained hints remain responsive with bounded REST refreshes`, async ({ page, context }, info) => {
  172 |     test.setTimeout(90_000);
  173 |     const data = await setup(page);
  174 |     const cdp = await context.newCDPSession(page);
  175 |     await cdp.send('Performance.enable');
  176 |     const sample = async () => {
  177 |       await cdp.send('HeapProfiler.collectGarbage');
  178 |       const { metrics } = await cdp.send('Performance.getMetrics');
  179 |       return Object.fromEntries(metrics.filter(metric => ['JSHeapUsedSize', 'Nodes', 'TaskDuration'].includes(metric.name))
  180 |         .map(metric => [metric.name, metric.value]));
  181 |     };
  182 |     await page.goto(screen === 'overview' ? '/dashboard' : screen === 'service' ? `/services/${SCOPE}` : '/incidents/resource-incident-0');
  183 |     await expect(page.locator(screen === 'overview' ? '.overview-panels' : screen === 'service' ? '.service-hero' : '.incident-summary-bar')).toBeVisible();
  184 |     await page.waitForTimeout(300);
  185 |     const records = [];
  186 |     for (const hz of [1, 100]) {
  187 |       data.delay(400);
  188 |       data.advance();
  189 |       const reads = screen === 'investigation' ? data.detailReads : data.serviceReads;
  190 |       const beforeReads = reads(), beforeIncidents = data.incidentReads();
  191 |       const before = await sample();
  192 |       const durationMs = 6000;
> 193 |       const measured = await page.evaluate(async ({ hz, durationMs }) => {
      |                                   ^ Error: page.evaluate: Execution context was destroyed, most likely because of a navigation.
  194 |         const state = (window as any).__resource;
  195 |         const frames: number[] = [], longTasks: number[] = [];
  196 |         const observer = new PerformanceObserver(list => {
  197 |           for (const task of list.getEntries()) if (longTasks.length < 100) longTasks.push(task.duration);
  198 |         });
  199 |         observer.observe({ entryTypes: ['longtask'] });
  200 |         performance.clearResourceTimings();
  201 |         let last = performance.now(), running = true, events = 0;
  202 |         const frame = () => {
  203 |           const now = performance.now();
  204 |           if (frames.length < 2000) frames.push(now - last);
  205 |           last = now;
  206 |           if (running) requestAnimationFrame(frame);
  207 |         };
  208 |         requestAnimationFrame(frame);
  209 |         const timer = setInterval(() => { state.stream.hint(); events++; }, 1000 / hz);
  210 |         await new Promise(resolve => setTimeout(resolve, durationMs));
  211 |         clearInterval(timer);
  212 |         running = false;
  213 |         observer.disconnect();
  214 |         return { events, frames, longTasks, activeStreams: state.active };
  215 |       }, { hz, durationMs });
  216 |       const readsDuringLoad = reads() - beforeReads;
  217 |       // REST updates must happen during the burst, rather than only after it ends.
  218 |       expect(readsDuringLoad).toBeGreaterThanOrEqual(hz === 1 ? 2 : 4);
  219 |       expect(readsDuringLoad).toBeLessThanOrEqual(8);
  220 |       expect(measured.activeStreams).toBe(1);
  221 |       await paint(page);
  222 |       const inputStarted = performance.now();
  223 |       if (screen !== 'investigation') {
  224 |         const input = page.getByLabel('From (UTC)', { exact: true });
  225 |         await input.focus();
  226 |         await input.press('ArrowLeft');
  227 |         await paint(page);
  228 |         await expect(input).toBeFocused();
  229 |       }
  230 |       const inputPaintMs = performance.now() - inputStarted;
  231 |       await page.waitForTimeout(1600);
  232 |       const apiRoundTrips = await page.evaluate(() => performance.getEntriesByType('resource')
  233 |         .filter(entry => /^\/api\/(services|incidents|geography)/.test(new URL(entry.name).pathname)
  234 |           && !entry.name.includes('/stream'))
  235 |         .map(entry => ({ path: new URL(entry.name).pathname, durationMs: entry.duration })));
  236 |       const after = await sample();
  237 |       const ordered = measured.frames.sort((a, b) => a - b);
  238 |       records.push({ requestedHintHz: hz, durationMs, events: measured.events,
  239 |         snapshotReadsDuringLoad: readsDuringLoad, incidentPageReads: data.incidentReads() - beforeIncidents,
  240 |         frameGapP95Ms: ordered[Math.ceil(ordered.length * .95) - 1], maxFrameGapMs: ordered.at(-1),
  241 |         longTasksMs: measured.longTasks, inputPaintMs, apiRoundTrips, before, after });
  242 |       if (screen === 'service') {
  243 |         await expect(page.locator('.actual-dot')).toHaveCount(60);
  244 |         await expect(page.locator('[data-window-id]')).toHaveCount(50);
  245 |         await expect(page.locator('.episode-card')).toHaveCount(20);
  246 |       }
  247 |       if (screen === 'investigation') await expect(page.locator('[data-detection-id]')).toHaveCount(20);
  248 |       expect(await page.evaluate(() => (window as any).__resource.active)).toBe(1);
  249 |     }
  250 |     await navigateToLoginAndExpectCleanup(page);
  251 |     await writeFile(info.outputPath('load-performance.json'), JSON.stringify({
  252 |       mode: 'Controlled REST responses and SSE; not LIVE acceptance', screen,
  253 |       scopeCount, incidentTotal: 1000, responseDelayMs: 400, records,
  254 |     }, null, 2));
  255 |     await cdp.detach();
  256 |   });
  257 | 
  258 |   test('bounds history, replaces pages, and retains one tab stream across workspace routes', async ({ page }) => {
  259 |     const data = await setup(page);
  260 |     await page.goto(`/services/${SCOPE}`);
  261 |     await expect(page.locator('.episode-card')).toHaveCount(20);
  262 |     await expect(page.locator('[data-window-id]')).toHaveCount(50);
  263 | 
  264 |     const before = data.reads();
  265 |     await page.getByLabel('From (UTC)', { exact: true }).fill('2026-10-04T11:00');
  266 |     await page.getByLabel('To (UTC, exclusive)').fill('2026-10-05T12:00');
  267 |     await page.getByRole('button', { name: 'Apply time range' }).click();
  268 |     await expect(page.getByRole('alert')).toContainText('at most 24 hours');
  269 |     expect(data.reads()).toBe(before);
  270 | 
  271 |     await page.getByLabel('From (UTC)', { exact: true }).fill('2026-10-04T12:00');
  272 |     await page.getByRole('button', { name: 'Apply time range' }).click();
  273 |     // Dense history is one path; retain every observation without 1,440 DOM markers.
  274 |     await expect.poll(async () => (await page.locator('.service-hero .actual-line').getAttribute('d'))?.match(/[ML]/g)?.length ?? 0).toBe(1440);
  275 |     expect(data.reads() - before).toBe(15);
  276 |     await expect(page.locator('[data-window-id]')).toHaveCount(50);
  277 |     await page.locator('.exact-values > summary').click();
  278 |     const firstWindow = await page.locator('[data-window-id]').first().getAttribute('data-window-id');
  279 |     await page.getByRole('navigation', { name: 'History table pages' }).getByRole('button', { name: 'Next windows' }).click();
  280 |     await expect(page.locator('[data-window-id]').first()).not.toHaveAttribute('data-window-id', firstWindow!);
  281 |     await expect(page.locator('[data-window-id]')).toHaveCount(50);
  282 | 
  283 |     await expect(page.getByRole('button', { name: 'Next incidents' })).toBeEnabled();
  284 |     await page.getByRole('button', { name: 'Next incidents' }).click();
  285 |     await expect(page.locator('.episode-card').first()).toHaveAttribute('data-episode-id', 'resource-episode-20');
  286 |     expect(data.incidentPage()).toBe(1);
  287 |     await expect(page.locator('.episode-card')).toHaveCount(20);
  288 |     const readsBeforeHint = data.incidentReads();
  289 |     await page.evaluate(() => (window as any).__resource.stream.hint());
  290 |     await expect.poll(data.incidentReads).toBeGreaterThan(readsBeforeHint);
  291 |     await expect(page.getByText('Updating…', { exact: true })).toHaveCount(0);
  292 |     await expect(page.locator('.episode-card')).toHaveCount(20);
  293 | 
```