# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: resource-bounds.spec.ts >> Browser resource bounds >> investigation: sustained hints remain responsive with bounded REST refreshes
- Location: tests/e2e/specs/resource-bounds.spec.ts:171:70

# Error details

```
Test timeout of 90000ms exceeded.
```

```
Error: page.evaluate: Test timeout of 90000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - link "Skip to workspace":
    - /url: "#workspace"
  - generic [ref=e3]:
    - complementary [ref=e4]:
      - link "Trace Link — Service overview" [ref=e5] [cursor=pointer]:
        - /url: /dashboard
      - navigation "Workspace" [ref=e7]:
        - link "Service overview" [ref=e8] [cursor=pointer]:
          - /url: /dashboard
        - link "Trace Link history" [ref=e12] [cursor=pointer]:
          - /url: /trace-link
      - generic [ref=e16]:
        - link "VoLTE setup" [ref=e17] [cursor=pointer]:
          - /url: /services/VOLTE-MD-CENTRAL
        - generic "SMS delivery" [ref=e21]
        - link "Roaming investigation" [ref=e25] [cursor=pointer]:
          - /url: /roaming
        - link "Incident investigation" [ref=e29] [cursor=pointer]:
          - /url: /dashboard#incident-queue
      - button "Expand sidebar" [ref=e34] [cursor=pointer]
    - generic [ref=e38]:
      - banner [ref=e39]:
        - generic [ref=e40]:
          - generic [ref=e41]: Workspace
          - generic [ref=e42]: /
          - strong [ref=e43]: Incident investigation
        - generic [ref=e44]:
          - generic [ref=e45]: Session connected
          - button "Notifications, 0 unread" [ref=e48] [cursor=pointer]:
            - text: Notifications
            - generic [aria-hidden] [ref=e49]: "0"
          - generic [ref=e50]:
            - generic [ref=e51]: RE
            - generic [ref=e52]:
              - text: Resource tester
              - generic [ref=e53]: ANALYST · until 20:03 UTC
          - button "Sign out" [ref=e54] [cursor=pointer]
      - main [ref=e58]:
        - generic [ref=e59]:
          - generic [ref=e60]:
            - generic [ref=e61]:
              - paragraph [ref=e62]: Analyst workspace
              - heading "Incident investigation" [level=1] [ref=e63]
              - paragraph [ref=e64]: Follow the evidence. Coordinate the response.
            - button "Refresh incident" [ref=e65] [cursor=pointer]
          - link "Back to service" [ref=e69] [cursor=pointer]:
            - /url: /services/VOLTE-MD-CENTRAL
          - generic [ref=e73]:
            - generic [ref=e74]:
              - paragraph [ref=e75]: Incident episode
              - heading "VoLTE setup" [level=2] [ref=e76]
            - generic [ref=e77]:
              - generic [ref=e78]:
                - generic [ref=e79]: Severity
                - strong [ref=e80]: HIGH
              - generic [ref=e81]:
                - generic [ref=e82]: Technical state
                - strong [ref=e83]: RECOVERED
              - generic [ref=e84]:
                - generic [ref=e85]: Analyst workflow
                - strong [ref=e86]: OPEN · Awaiting analyst resolution
              - generic [ref=e87]:
                - generic [ref=e88]: Assignee
                - strong [ref=e89]: Unassigned
              - generic [ref=e90]:
                - generic [ref=e91]: Latest KPI deviation
                - strong [ref=e92]: "Call setup success rate: +0.3 pp"
            - button "Details & workflow" [ref=e93] [cursor=pointer]
          - region "Current incident times" [ref=e97]:
            - generic [ref=e98]:
              - generic [ref=e99]:
                - term [ref=e100]: First observed (UTC)
                - definition [ref=e101]: 15 Sep 2026 10:02:00
              - generic [ref=e102]:
                - term [ref=e103]: Detected (UTC)
                - definition [ref=e104]: 05 Oct 2026 12:02:00
              - generic [ref=e105]:
                - term [ref=e106]: Last observed (UTC)
                - definition [ref=e107]: 15 Sep 2026 10:08:00
              - generic [ref=e108]:
                - term [ref=e109]: Updated (UTC)
                - definition [ref=e110]: 15 Sep 2026 10:08:10
              - generic [ref=e111]:
                - term [ref=e112]: Recovery detected (UTC)
                - definition [ref=e113]: 15 Sep 2026 10:08:10
          - generic [ref=e114]:
            - paragraph [ref=e115]: Evidence page 1 · 20 shown · 1000 total. This page is part of the timeline; the incident summary shows the current state.
            - navigation "Evidence pages" [ref=e116]:
              - button "Previous evidence" [disabled] [ref=e117]
              - generic [ref=e121]: 1 / 50
              - button "Next evidence" [ref=e122] [cursor=pointer]
            - generic [ref=e126]:
              - heading "Evidence timeline" [level=2] [ref=e127]
              - paragraph [ref=e128]: Accepted detection records, ordered by sequence from earliest to latest. Each update preserves the evidence recorded for its own window.
              - article [ref=e129]:
                - generic [ref=e134]:
                  - generic [ref=e135]:
                    - heading "Update 1 · RECOVERY" [level=3] [ref=e136]
                    - paragraph [ref=e137]: 15 Sep 10:07:00 – 15 Sep 10:08:00 UTC
                  - generic [ref=e138]:
                    - generic [ref=e139]:
                      - generic [ref=e140]: "Severity:"
                      - text: HIGH
                    - generic [ref=e141]:
                      - generic [ref=e142]: "Technical state:"
                      - text: RECOVERED
                    - generic [ref=e143]: RECOVERY
                - paragraph [ref=e144]:
                  - text: Server detected at
                  - time [ref=e145]: 15 Sep 2026 10:08:10
                  - text: "UTC · Service: VOLTE"
                - heading "Observed evidence" [level=4] [ref=e146]
                - region "KPI evidence for update 1" [ref=e147]:
                  - table [ref=e148]:
                    - caption [ref=e149]: Measured KPIs for update 1
                    - rowgroup [ref=e150]:
                      - row [ref=e151]:
                        - columnheader "KPI" [ref=e152]
                        - columnheader "Actual" [ref=e153]
                        - columnheader "Baseline" [ref=e154]
                        - columnheader "Unit" [ref=e155]
                        - columnheader "Change" [ref=e156]
                        - columnheader "Relative change" [ref=e157]
                        - columnheader "Numerator" [ref=e158]
                        - columnheader "Denominator" [ref=e159]
                    - rowgroup [ref=e160]:
                      - row [ref=e161]:
                        - rowheader "Call setup success rate" [ref=e162]
                        - cell "99.6" [ref=e163]
                        - cell "99.3" [ref=e164]
                        - cell "PERCENT" [ref=e165]
                        - cell "+0.3 pp" [ref=e166]
                        - cell "+0.3%" [ref=e167]
                        - cell "996" [ref=e168]
                        - cell "1000" [ref=e169]
                - paragraph [ref=e170]:
                  - strong [ref=e171]: Estimated impact
                  - text: "· Estimated extra failed attempts: 0"
                - group [ref=e172]:
                  - generic "Troubleshooting" [ref=e173] [cursor=pointer]
                - group [ref=e174]:
                  - generic "Cause hypothesis & recommended checks" [ref=e175] [cursor=pointer]
              - article [ref=e176]:
                - generic [ref=e181]:
                  - generic [ref=e182]:
                    - heading "Update 2 · RECOVERY" [level=3] [ref=e183]
                    - paragraph [ref=e184]: 15 Sep 10:07:00 – 15 Sep 10:08:00 UTC
                  - generic [ref=e185]:
                    - generic [ref=e186]:
                      - generic [ref=e187]: "Severity:"
                      - text: HIGH
                    - generic [ref=e188]:
                      - generic [ref=e189]: "Technical state:"
                      - text: RECOVERED
                    - generic [ref=e190]: RECOVERY
                - paragraph [ref=e191]:
                  - text: Server detected at
                  - time [ref=e192]: 15 Sep 2026 10:08:10
                  - text: "UTC · Service: VOLTE"
                - heading "Observed evidence" [level=4] [ref=e193]
                - region "KPI evidence for update 2" [ref=e194]:
                  - table [ref=e195]:
                    - caption [ref=e196]: Measured KPIs for update 2
                    - rowgroup [ref=e197]:
                      - row [ref=e198]:
                        - columnheader "KPI" [ref=e199]
                        - columnheader "Actual" [ref=e200]
                        - columnheader "Baseline" [ref=e201]
                        - columnheader "Unit" [ref=e202]
                        - columnheader "Change" [ref=e203]
                        - columnheader "Relative change" [ref=e204]
                        - columnheader "Numerator" [ref=e205]
                        - columnheader "Denominator" [ref=e206]
                    - rowgroup [ref=e207]:
                      - row [ref=e208]:
                        - rowheader "Call setup success rate" [ref=e209]
                        - cell "99.6" [ref=e210]
                        - cell "99.3" [ref=e211]
                        - cell "PERCENT" [ref=e212]
                        - cell "+0.3 pp" [ref=e213]
                        - cell "+0.3%" [ref=e214]
                        - cell "996" [ref=e215]
                        - cell "1000" [ref=e216]
                - paragraph [ref=e217]:
                  - strong [ref=e218]: Estimated impact
                  - text: "· Estimated extra failed attempts: 0"
                - group [ref=e219]:
                  - generic "Troubleshooting" [ref=e220] [cursor=pointer]
                - group [ref=e221]:
                  - generic "Cause hypothesis & recommended checks" [ref=e222] [cursor=pointer]
              - article [ref=e223]:
                - generic [ref=e228]:
                  - generic [ref=e229]:
                    - heading "Update 3 · RECOVERY" [level=3] [ref=e230]
                    - paragraph [ref=e231]: 15 Sep 10:07:00 – 15 Sep 10:08:00 UTC
                  - generic [ref=e232]:
                    - generic [ref=e233]:
                      - generic [ref=e234]: "Severity:"
                      - text: HIGH
                    - generic [ref=e235]:
                      - generic [ref=e236]: "Technical state:"
                      - text: RECOVERED
                    - generic [ref=e237]: RECOVERY
                - paragraph [ref=e238]:
                  - text: Server detected at
                  - time [ref=e239]: 15 Sep 2026 10:08:10
                  - text: "UTC · Service: VOLTE"
                - heading "Observed evidence" [level=4] [ref=e240]
                - region "KPI evidence for update 3" [ref=e241]:
                  - table [ref=e242]:
                    - caption [ref=e243]: Measured KPIs for update 3
                    - rowgroup [ref=e244]:
                      - row [ref=e245]:
                        - columnheader "KPI" [ref=e246]
                        - columnheader "Actual" [ref=e247]
                        - columnheader "Baseline" [ref=e248]
                        - columnheader "Unit" [ref=e249]
                        - columnheader "Change" [ref=e250]
                        - columnheader "Relative change" [ref=e251]
                        - columnheader "Numerator" [ref=e252]
                        - columnheader "Denominator" [ref=e253]
                    - rowgroup [ref=e254]:
                      - row [ref=e255]:
                        - rowheader "Call setup success rate" [ref=e256]
                        - cell "99.6" [ref=e257]
                        - cell "99.3" [ref=e258]
                        - cell "PERCENT" [ref=e259]
                        - cell "+0.3 pp" [ref=e260]
                        - cell "+0.3%" [ref=e261]
                        - cell "996" [ref=e262]
                        - cell "1000" [ref=e263]
                - paragraph [ref=e264]:
                  - strong [ref=e265]: Estimated impact
                  - text: "· Estimated extra failed attempts: 0"
                - group [ref=e266]:
                  - generic "Troubleshooting" [ref=e267] [cursor=pointer]
                - group [ref=e268]:
                  - generic "Cause hypothesis & recommended checks" [ref=e269] [cursor=pointer]
              - article [ref=e270]:
                - generic [ref=e275]:
                  - generic [ref=e276]:
                    - heading "Update 4 · RECOVERY" [level=3] [ref=e277]
                    - paragraph [ref=e278]: 15 Sep 10:07:00 – 15 Sep 10:08:00 UTC
                  - generic [ref=e279]:
                    - generic [ref=e280]:
                      - generic [ref=e281]: "Severity:"
                      - text: HIGH
                    - generic [ref=e282]:
                      - generic [ref=e283]: "Technical state:"
                      - text: RECOVERED
                    - generic [ref=e284]: RECOVERY
                - paragraph [ref=e285]:
                  - text: Server detected at
                  - time [ref=e286]: 15 Sep 2026 10:08:10
                  - text: "UTC · Service: VOLTE"
                - heading "Observed evidence" [level=4] [ref=e287]
                - region "KPI evidence for update 4" [ref=e288]:
                  - table [ref=e289]:
                    - caption [ref=e290]: Measured KPIs for update 4
                    - rowgroup [ref=e291]:
                      - row [ref=e292]:
                        - columnheader "KPI" [ref=e293]
                        - columnheader "Actual" [ref=e294]
                        - columnheader "Baseline" [ref=e295]
                        - columnheader "Unit" [ref=e296]
                        - columnheader "Change" [ref=e297]
                        - columnheader "Relative change" [ref=e298]
                        - columnheader "Numerator" [ref=e299]
                        - columnheader "Denominator" [ref=e300]
                    - rowgroup [ref=e301]:
                      - row [ref=e302]:
                        - rowheader "Call setup success rate" [ref=e303]
                        - cell "99.6" [ref=e304]
                        - cell "99.3" [ref=e305]
                        - cell "PERCENT" [ref=e306]
                        - cell "+0.3 pp" [ref=e307]
                        - cell "+0.3%" [ref=e308]
                        - cell "996" [ref=e309]
                        - cell "1000" [ref=e310]
                - paragraph [ref=e311]:
                  - strong [ref=e312]: Estimated impact
                  - text: "· Estimated extra failed attempts: 0"
                - group [ref=e313]:
                  - generic "Troubleshooting" [ref=e314] [cursor=pointer]
                - group [ref=e315]:
                  - generic "Cause hypothesis & recommended checks" [ref=e316] [cursor=pointer]
              - article [ref=e317]:
                - generic [ref=e322]:
                  - generic [ref=e323]:
                    - heading "Update 5 · RECOVERY" [level=3] [ref=e324]
                    - paragraph [ref=e325]: 15 Sep 10:07:00 – 15 Sep 10:08:00 UTC
                  - generic [ref=e326]:
                    - generic [ref=e327]:
                      - generic [ref=e328]: "Severity:"
                      - text: HIGH
                    - generic [ref=e329]:
                      - generic [ref=e330]: "Technical state:"
                      - text: RECOVERED
                    - generic [ref=e331]: RECOVERY
                - paragraph [ref=e332]:
                  - text: Server detected at
                  - time [ref=e333]: 15 Sep 2026 10:08:10
                  - text: "UTC · Service: VOLTE"
                - heading "Observed evidence" [level=4] [ref=e334]
                - region "KPI evidence for update 5" [ref=e335]:
                  - table [ref=e336]:
                    - caption [ref=e337]: Measured KPIs for update 5
                    - rowgroup [ref=e338]:
                      - row [ref=e339]:
                        - columnheader "KPI" [ref=e340]
                        - columnheader "Actual" [ref=e341]
                        - columnheader "Baseline" [ref=e342]
                        - columnheader "Unit" [ref=e343]
                        - columnheader "Change" [ref=e344]
                        - columnheader "Relative change" [ref=e345]
                        - columnheader "Numerator" [ref=e346]
                        - columnheader "Denominator" [ref=e347]
                    - rowgroup [ref=e348]:
                      - row [ref=e349]:
                        - rowheader "Call setup success rate" [ref=e350]
                        - cell "99.6" [ref=e351]
                        - cell "99.3" [ref=e352]
                        - cell "PERCENT" [ref=e353]
                        - cell "+0.3 pp" [ref=e354]
                        - cell "+0.3%" [ref=e355]
                        - cell "996" [ref=e356]
                        - cell "1000" [ref=e357]
                - paragraph [ref=e358]:
                  - strong [ref=e359]: Estimated impact
                  - text: "· Estimated extra failed attempts: 0"
                - group [ref=e360]:
                  - generic "Troubleshooting" [ref=e361] [cursor=pointer]
                - group [ref=e362]:
                  - generic "Cause hypothesis & recommended checks" [ref=e363] [cursor=pointer]
              - article [ref=e364]:
                - generic [ref=e369]:
                  - generic [ref=e370]:
                    - heading "Update 6 · RECOVERY" [level=3] [ref=e371]
                    - paragraph [ref=e372]: 15 Sep 10:07:00 – 15 Sep 10:08:00 UTC
                  - generic [ref=e373]:
                    - generic [ref=e374]:
                      - generic [ref=e375]: "Severity:"
                      - text: HIGH
                    - generic [ref=e376]:
                      - generic [ref=e377]: "Technical state:"
                      - text: RECOVERED
                    - generic [ref=e378]: RECOVERY
                - paragraph [ref=e379]:
                  - text: Server detected at
                  - time [ref=e380]: 15 Sep 2026 10:08:10
                  - text: "UTC · Service: VOLTE"
                - heading "Observed evidence" [level=4] [ref=e381]
                - region "KPI evidence for update 6" [ref=e382]:
                  - table [ref=e383]:
                    - caption [ref=e384]: Measured KPIs for update 6
                    - rowgroup [ref=e385]:
                      - row [ref=e386]:
                        - columnheader "KPI" [ref=e387]
                        - columnheader "Actual" [ref=e388]
                        - columnheader "Baseline" [ref=e389]
                        - columnheader "Unit" [ref=e390]
                        - columnheader "Change" [ref=e391]
                        - columnheader "Relative change" [ref=e392]
                        - columnheader "Numerator" [ref=e393]
                        - columnheader "Denominator" [ref=e394]
                    - rowgroup [ref=e395]:
                      - row [ref=e396]:
                        - rowheader "Call setup success rate" [ref=e397]
                        - cell "99.6" [ref=e398]
                        - cell "99.3" [ref=e399]
                        - cell "PERCENT" [ref=e400]
                        - cell "+0.3 pp" [ref=e401]
                        - cell "+0.3%" [ref=e402]
                        - cell "996" [ref=e403]
                        - cell "1000" [ref=e404]
                - paragraph [ref=e405]:
                  - strong [ref=e406]: Estimated impact
                  - text: "· Estimated extra failed attempts: 0"
                - group [ref=e407]:
                  - generic "Troubleshooting" [ref=e408] [cursor=pointer]
                - group [ref=e409]:
                  - generic "Cause hypothesis & recommended checks" [ref=e410] [cursor=pointer]
              - article [ref=e411]:
                - generic [ref=e416]:
                  - generic [ref=e417]:
                    - heading "Update 7 · RECOVERY" [level=3] [ref=e418]
                    - paragraph [ref=e419]: 15 Sep 10:07:00 – 15 Sep 10:08:00 UTC
                  - generic [ref=e420]:
                    - generic [ref=e421]:
                      - generic [ref=e422]: "Severity:"
                      - text: HIGH
                    - generic [ref=e423]:
                      - generic [ref=e424]: "Technical state:"
                      - text: RECOVERED
                    - generic [ref=e425]: RECOVERY
                - paragraph [ref=e426]:
                  - text: Server detected at
                  - time [ref=e427]: 15 Sep 2026 10:08:10
                  - text: "UTC · Service: VOLTE"
                - heading "Observed evidence" [level=4] [ref=e428]
                - region "KPI evidence for update 7" [ref=e429]:
                  - table [ref=e430]:
                    - caption [ref=e431]: Measured KPIs for update 7
                    - rowgroup [ref=e432]:
                      - row [ref=e433]:
                        - columnheader "KPI" [ref=e434]
                        - columnheader "Actual" [ref=e435]
                        - columnheader "Baseline" [ref=e436]
                        - columnheader "Unit" [ref=e437]
                        - columnheader "Change" [ref=e438]
                        - columnheader "Relative change" [ref=e439]
                        - columnheader "Numerator" [ref=e440]
                        - columnheader "Denominator" [ref=e441]
                    - rowgroup [ref=e442]:
                      - row [ref=e443]:
                        - rowheader "Call setup success rate" [ref=e444]
                        - cell "99.6" [ref=e445]
                        - cell "99.3" [ref=e446]
                        - cell "PERCENT" [ref=e447]
                        - cell "+0.3 pp" [ref=e448]
                        - cell "+0.3%" [ref=e449]
                        - cell "996" [ref=e450]
                        - cell "1000" [ref=e451]
                - paragraph [ref=e452]:
                  - strong [ref=e453]: Estimated impact
                  - text: "· Estimated extra failed attempts: 0"
                - group [ref=e454]:
                  - generic "Troubleshooting" [ref=e455] [cursor=pointer]
                - group [ref=e456]:
                  - generic "Cause hypothesis & recommended checks" [ref=e457] [cursor=pointer]
              - article [ref=e458]:
                - generic [ref=e463]:
                  - generic [ref=e464]:
                    - heading "Update 8 · RECOVERY" [level=3] [ref=e465]
                    - paragraph [ref=e466]: 15 Sep 10:07:00 – 15 Sep 10:08:00 UTC
                  - generic [ref=e467]:
                    - generic [ref=e468]:
                      - generic [ref=e469]: "Severity:"
                      - text: HIGH
                    - generic [ref=e470]:
                      - generic [ref=e471]: "Technical state:"
                      - text: RECOVERED
                    - generic [ref=e472]: RECOVERY
                - paragraph [ref=e473]:
                  - text: Server detected at
                  - time [ref=e474]: 15 Sep 2026 10:08:10
                  - text: "UTC · Service: VOLTE"
                - heading "Observed evidence" [level=4] [ref=e475]
                - region "KPI evidence for update 8" [ref=e476]:
                  - table [ref=e477]:
                    - caption [ref=e478]: Measured KPIs for update 8
                    - rowgroup [ref=e479]:
                      - row [ref=e480]:
                        - columnheader "KPI" [ref=e481]
                        - columnheader "Actual" [ref=e482]
                        - columnheader "Baseline" [ref=e483]
                        - columnheader "Unit" [ref=e484]
                        - columnheader "Change" [ref=e485]
                        - columnheader "Relative change" [ref=e486]
                        - columnheader "Numerator" [ref=e487]
                        - columnheader "Denominator" [ref=e488]
                    - rowgroup [ref=e489]:
                      - row [ref=e490]:
                        - rowheader "Call setup success rate" [ref=e491]
                        - cell "99.6" [ref=e492]
                        - cell "99.3" [ref=e493]
                        - cell "PERCENT" [ref=e494]
                        - cell "+0.3 pp" [ref=e495]
                        - cell "+0.3%" [ref=e496]
                        - cell "996" [ref=e497]
                        - cell "1000" [ref=e498]
                - paragraph [ref=e499]:
                  - strong [ref=e500]: Estimated impact
                  - text: "· Estimated extra failed attempts: 0"
                - group [ref=e501]:
                  - generic "Troubleshooting" [ref=e502] [cursor=pointer]
                - group [ref=e503]:
                  - generic "Cause hypothesis & recommended checks" [ref=e504] [cursor=pointer]
              - article [ref=e505]:
                - generic [ref=e510]:
                  - generic [ref=e511]:
                    - heading "Update 9 · RECOVERY" [level=3] [ref=e512]
                    - paragraph [ref=e513]: 15 Sep 10:07:00 – 15 Sep 10:08:00 UTC
                  - generic [ref=e514]:
                    - generic [ref=e515]:
                      - generic [ref=e516]: "Severity:"
                      - text: HIGH
                    - generic [ref=e517]:
                      - generic [ref=e518]: "Technical state:"
                      - text: RECOVERED
                    - generic [ref=e519]: RECOVERY
                - paragraph [ref=e520]:
                  - text: Server detected at
                  - time [ref=e521]: 15 Sep 2026 10:08:10
                  - text: "UTC · Service: VOLTE"
                - heading "Observed evidence" [level=4] [ref=e522]
                - region "KPI evidence for update 9" [ref=e523]:
                  - table [ref=e524]:
                    - caption [ref=e525]: Measured KPIs for update 9
                    - rowgroup [ref=e526]:
                      - row [ref=e527]:
                        - columnheader "KPI" [ref=e528]
                        - columnheader "Actual" [ref=e529]
                        - columnheader "Baseline" [ref=e530]
                        - columnheader "Unit" [ref=e531]
                        - columnheader "Change" [ref=e532]
                        - columnheader "Relative change" [ref=e533]
                        - columnheader "Numerator" [ref=e534]
                        - columnheader "Denominator" [ref=e535]
                    - rowgroup [ref=e536]:
                      - row [ref=e537]:
                        - rowheader "Call setup success rate" [ref=e538]
                        - cell "99.6" [ref=e539]
                        - cell "99.3" [ref=e540]
                        - cell "PERCENT" [ref=e541]
                        - cell "+0.3 pp" [ref=e542]
                        - cell "+0.3%" [ref=e543]
                        - cell "996" [ref=e544]
                        - cell "1000" [ref=e545]
                - paragraph [ref=e546]:
                  - strong [ref=e547]: Estimated impact
                  - text: "· Estimated extra failed attempts: 0"
                - group [ref=e548]:
                  - generic "Troubleshooting" [ref=e549] [cursor=pointer]
                - group [ref=e550]:
                  - generic "Cause hypothesis & recommended checks" [ref=e551] [cursor=pointer]
              - article [ref=e552]:
                - generic [ref=e557]:
                  - generic [ref=e558]:
                    - heading "Update 10 · RECOVERY" [level=3] [ref=e559]
                    - paragraph [ref=e560]: 15 Sep 10:07:00 – 15 Sep 10:08:00 UTC
                  - generic [ref=e561]:
                    - generic [ref=e562]:
                      - generic [ref=e563]: "Severity:"
                      - text: HIGH
                    - generic [ref=e564]:
                      - generic [ref=e565]: "Technical state:"
                      - text: RECOVERED
                    - generic [ref=e566]: RECOVERY
                - paragraph [ref=e567]:
                  - text: Server detected at
                  - time [ref=e568]: 15 Sep 2026 10:08:10
                  - text: "UTC · Service: VOLTE"
                - heading "Observed evidence" [level=4] [ref=e569]
                - region "KPI evidence for update 10" [ref=e570]:
                  - table [ref=e571]:
                    - caption [ref=e572]: Measured KPIs for update 10
                    - rowgroup [ref=e573]:
                      - row [ref=e574]:
                        - columnheader "KPI" [ref=e575]
                        - columnheader "Actual" [ref=e576]
                        - columnheader "Baseline" [ref=e577]
                        - columnheader "Unit" [ref=e578]
                        - columnheader "Change" [ref=e579]
                        - columnheader "Relative change" [ref=e580]
                        - columnheader "Numerator" [ref=e581]
                        - columnheader "Denominator" [ref=e582]
                    - rowgroup [ref=e583]:
                      - row [ref=e584]:
                        - rowheader "Call setup success rate" [ref=e585]
                        - cell "99.6" [ref=e586]
                        - cell "99.3" [ref=e587]
                        - cell "PERCENT" [ref=e588]
                        - cell "+0.3 pp" [ref=e589]
                        - cell "+0.3%" [ref=e590]
                        - cell "996" [ref=e591]
                        - cell "1000" [ref=e592]
                - paragraph [ref=e593]:
                  - strong [ref=e594]: Estimated impact
                  - text: "· Estimated extra failed attempts: 0"
                - group [ref=e595]:
                  - generic "Troubleshooting" [ref=e596] [cursor=pointer]
                - group [ref=e597]:
                  - generic "Cause hypothesis & recommended checks" [ref=e598] [cursor=pointer]
              - article [ref=e599]:
                - generic [ref=e604]:
                  - generic [ref=e605]:
                    - heading "Update 11 · RECOVERY" [level=3] [ref=e606]
                    - paragraph [ref=e607]: 15 Sep 10:07:00 – 15 Sep 10:08:00 UTC
                  - generic [ref=e608]:
                    - generic [ref=e609]:
                      - generic [ref=e610]: "Severity:"
                      - text: HIGH
                    - generic [ref=e611]:
                      - generic [ref=e612]: "Technical state:"
                      - text: RECOVERED
                    - generic [ref=e613]: RECOVERY
                - paragraph [ref=e614]:
                  - text: Server detected at
                  - time [ref=e615]: 15 Sep 2026 10:08:10
                  - text: "UTC · Service: VOLTE"
                - heading "Observed evidence" [level=4] [ref=e616]
                - region "KPI evidence for update 11" [ref=e617]:
                  - table [ref=e618]:
                    - caption [ref=e619]: Measured KPIs for update 11
                    - rowgroup [ref=e620]:
                      - row [ref=e621]:
                        - columnheader "KPI" [ref=e622]
                        - columnheader "Actual" [ref=e623]
                        - columnheader "Baseline" [ref=e624]
                        - columnheader "Unit" [ref=e625]
                        - columnheader "Change" [ref=e626]
                        - columnheader "Relative change" [ref=e627]
                        - columnheader "Numerator" [ref=e628]
                        - columnheader "Denominator" [ref=e629]
                    - rowgroup [ref=e630]:
                      - row [ref=e631]:
                        - rowheader "Call setup success rate" [ref=e632]
                        - cell "99.6" [ref=e633]
                        - cell "99.3" [ref=e634]
                        - cell "PERCENT" [ref=e635]
                        - cell "+0.3 pp" [ref=e636]
                        - cell "+0.3%" [ref=e637]
                        - cell "996" [ref=e638]
                        - cell "1000" [ref=e639]
                - paragraph [ref=e640]:
                  - strong [ref=e641]: Estimated impact
                  - text: "· Estimated extra failed attempts: 0"
                - group [ref=e642]:
                  - generic "Troubleshooting" [ref=e643] [cursor=pointer]
                - group [ref=e644]:
                  - generic "Cause hypothesis & recommended checks" [ref=e645] [cursor=pointer]
              - article [ref=e646]:
                - generic [ref=e651]:
                  - generic [ref=e652]:
                    - heading "Update 12 · RECOVERY" [level=3] [ref=e653]
                    - paragraph [ref=e654]: 15 Sep 10:07:00 – 15 Sep 10:08:00 UTC
                  - generic [ref=e655]:
                    - generic [ref=e656]:
                      - generic [ref=e657]: "Severity:"
                      - text: HIGH
                    - generic [ref=e658]:
                      - generic [ref=e659]: "Technical state:"
                      - text: RECOVERED
                    - generic [ref=e660]: RECOVERY
                - paragraph [ref=e661]:
                  - text: Server detected at
                  - time [ref=e662]: 15 Sep 2026 10:08:10
                  - text: "UTC · Service: VOLTE"
                - heading "Observed evidence" [level=4] [ref=e663]
                - region "KPI evidence for update 12" [ref=e664]:
                  - table [ref=e665]:
                    - caption [ref=e666]: Measured KPIs for update 12
                    - rowgroup [ref=e667]:
                      - row [ref=e668]:
                        - columnheader "KPI" [ref=e669]
                        - columnheader "Actual" [ref=e670]
                        - columnheader "Baseline" [ref=e671]
                        - columnheader "Unit" [ref=e672]
                        - columnheader "Change" [ref=e673]
                        - columnheader "Relative change" [ref=e674]
                        - columnheader "Numerator" [ref=e675]
                        - columnheader "Denominator" [ref=e676]
                    - rowgroup [ref=e677]:
                      - row [ref=e678]:
                        - rowheader "Call setup success rate" [ref=e679]
                        - cell "99.6" [ref=e680]
                        - cell "99.3" [ref=e681]
                        - cell "PERCENT" [ref=e682]
                        - cell "+0.3 pp" [ref=e683]
                        - cell "+0.3%" [ref=e684]
                        - cell "996" [ref=e685]
                        - cell "1000" [ref=e686]
                - paragraph [ref=e687]:
                  - strong [ref=e688]: Estimated impact
                  - text: "· Estimated extra failed attempts: 0"
                - group [ref=e689]:
                  - generic "Troubleshooting" [ref=e690] [cursor=pointer]
                - group [ref=e691]:
                  - generic "Cause hypothesis & recommended checks" [ref=e692] [cursor=pointer]
              - article [ref=e693]:
                - generic [ref=e698]:
                  - generic [ref=e699]:
                    - heading "Update 13 · RECOVERY" [level=3] [ref=e700]
                    - paragraph [ref=e701]: 15 Sep 10:07:00 – 15 Sep 10:08:00 UTC
                  - generic [ref=e702]:
                    - generic [ref=e703]:
                      - generic [ref=e704]: "Severity:"
                      - text: HIGH
                    - generic [ref=e705]:
                      - generic [ref=e706]: "Technical state:"
                      - text: RECOVERED
                    - generic [ref=e707]: RECOVERY
                - paragraph [ref=e708]:
                  - text: Server detected at
                  - time [ref=e709]: 15 Sep 2026 10:08:10
                  - text: "UTC · Service: VOLTE"
                - heading "Observed evidence" [level=4] [ref=e710]
                - region "KPI evidence for update 13" [ref=e711]:
                  - table [ref=e712]:
                    - caption [ref=e713]: Measured KPIs for update 13
                    - rowgroup [ref=e714]:
                      - row [ref=e715]:
                        - columnheader "KPI" [ref=e716]
                        - columnheader "Actual" [ref=e717]
                        - columnheader "Baseline" [ref=e718]
                        - columnheader "Unit" [ref=e719]
                        - columnheader "Change" [ref=e720]
                        - columnheader "Relative change" [ref=e721]
                        - columnheader "Numerator" [ref=e722]
                        - columnheader "Denominator" [ref=e723]
                    - rowgroup [ref=e724]:
                      - row [ref=e725]:
                        - rowheader "Call setup success rate" [ref=e726]
                        - cell "99.6" [ref=e727]
                        - cell "99.3" [ref=e728]
                        - cell "PERCENT" [ref=e729]
                        - cell "+0.3 pp" [ref=e730]
                        - cell "+0.3%" [ref=e731]
                        - cell "996" [ref=e732]
                        - cell "1000" [ref=e733]
                - paragraph [ref=e734]:
                  - strong [ref=e735]: Estimated impact
                  - text: "· Estimated extra failed attempts: 0"
                - group [ref=e736]:
                  - generic "Troubleshooting" [ref=e737] [cursor=pointer]
                - group [ref=e738]:
                  - generic "Cause hypothesis & recommended checks" [ref=e739] [cursor=pointer]
              - article [ref=e740]:
                - generic [ref=e745]:
                  - generic [ref=e746]:
                    - heading "Update 14 · RECOVERY" [level=3] [ref=e747]
                    - paragraph [ref=e748]: 15 Sep 10:07:00 – 15 Sep 10:08:00 UTC
                  - generic [ref=e749]:
                    - generic [ref=e750]:
                      - generic [ref=e751]: "Severity:"
                      - text: HIGH
                    - generic [ref=e752]:
                      - generic [ref=e753]: "Technical state:"
                      - text: RECOVERED
                    - generic [ref=e754]: RECOVERY
                - paragraph [ref=e755]:
                  - text: Server detected at
                  - time [ref=e756]: 15 Sep 2026 10:08:10
                  - text: "UTC · Service: VOLTE"
                - heading "Observed evidence" [level=4] [ref=e757]
                - region "KPI evidence for update 14" [ref=e758]:
                  - table [ref=e759]:
                    - caption [ref=e760]: Measured KPIs for update 14
                    - rowgroup [ref=e761]:
                      - row [ref=e762]:
                        - columnheader "KPI" [ref=e763]
                        - columnheader "Actual" [ref=e764]
                        - columnheader "Baseline" [ref=e765]
                        - columnheader "Unit" [ref=e766]
                        - columnheader "Change" [ref=e767]
                        - columnheader "Relative change" [ref=e768]
                        - columnheader "Numerator" [ref=e769]
                        - columnheader "Denominator" [ref=e770]
                    - rowgroup [ref=e771]:
                      - row [ref=e772]:
                        - rowheader "Call setup success rate" [ref=e773]
                        - cell "99.6" [ref=e774]
                        - cell "99.3" [ref=e775]
                        - cell "PERCENT" [ref=e776]
                        - cell "+0.3 pp" [ref=e777]
                        - cell "+0.3%" [ref=e778]
                        - cell "996" [ref=e779]
                        - cell "1000" [ref=e780]
                - paragraph [ref=e781]:
                  - strong [ref=e782]: Estimated impact
                  - text: "· Estimated extra failed attempts: 0"
                - group [ref=e783]:
                  - generic "Troubleshooting" [ref=e784] [cursor=pointer]
                - group [ref=e785]:
                  - generic "Cause hypothesis & recommended checks" [ref=e786] [cursor=pointer]
              - article [ref=e787]:
                - generic [ref=e792]:
                  - generic [ref=e793]:
                    - heading "Update 15 · RECOVERY" [level=3] [ref=e794]
                    - paragraph [ref=e795]: 15 Sep 10:07:00 – 15 Sep 10:08:00 UTC
                  - generic [ref=e796]:
                    - generic [ref=e797]:
                      - generic [ref=e798]: "Severity:"
                      - text: HIGH
                    - generic [ref=e799]:
                      - generic [ref=e800]: "Technical state:"
                      - text: RECOVERED
                    - generic [ref=e801]: RECOVERY
                - paragraph [ref=e802]:
                  - text: Server detected at
                  - time [ref=e803]: 15 Sep 2026 10:08:10
                  - text: "UTC · Service: VOLTE"
                - heading "Observed evidence" [level=4] [ref=e804]
                - region "KPI evidence for update 15" [ref=e805]:
                  - table [ref=e806]:
                    - caption [ref=e807]: Measured KPIs for update 15
                    - rowgroup [ref=e808]:
                      - row [ref=e809]:
                        - columnheader "KPI" [ref=e810]
                        - columnheader "Actual" [ref=e811]
                        - columnheader "Baseline" [ref=e812]
                        - columnheader "Unit" [ref=e813]
                        - columnheader "Change" [ref=e814]
                        - columnheader "Relative change" [ref=e815]
                        - columnheader "Numerator" [ref=e816]
                        - columnheader "Denominator" [ref=e817]
                    - rowgroup [ref=e818]:
                      - row [ref=e819]:
                        - rowheader "Call setup success rate" [ref=e820]
                        - cell "99.6" [ref=e821]
                        - cell "99.3" [ref=e822]
                        - cell "PERCENT" [ref=e823]
                        - cell "+0.3 pp" [ref=e824]
                        - cell "+0.3%" [ref=e825]
                        - cell "996" [ref=e826]
                        - cell "1000" [ref=e827]
                - paragraph [ref=e828]:
                  - strong [ref=e829]: Estimated impact
                  - text: "· Estimated extra failed attempts: 0"
                - group [ref=e830]:
                  - generic "Troubleshooting" [ref=e831] [cursor=pointer]
                - group [ref=e832]:
                  - generic "Cause hypothesis & recommended checks" [ref=e833] [cursor=pointer]
              - article [ref=e834]:
                - generic [ref=e839]:
                  - generic [ref=e840]:
                    - heading "Update 16 · RECOVERY" [level=3] [ref=e841]
                    - paragraph [ref=e842]: 15 Sep 10:07:00 – 15 Sep 10:08:00 UTC
                  - generic [ref=e843]:
                    - generic [ref=e844]:
                      - generic [ref=e845]: "Severity:"
                      - text: HIGH
                    - generic [ref=e846]:
                      - generic [ref=e847]: "Technical state:"
                      - text: RECOVERED
                    - generic [ref=e848]: RECOVERY
                - paragraph [ref=e849]:
                  - text: Server detected at
                  - time [ref=e850]: 15 Sep 2026 10:08:10
                  - text: "UTC · Service: VOLTE"
                - heading "Observed evidence" [level=4] [ref=e851]
                - region "KPI evidence for update 16" [ref=e852]:
                  - table [ref=e853]:
                    - caption [ref=e854]: Measured KPIs for update 16
                    - rowgroup [ref=e855]:
                      - row [ref=e856]:
                        - columnheader "KPI" [ref=e857]
                        - columnheader "Actual" [ref=e858]
                        - columnheader "Baseline" [ref=e859]
                        - columnheader "Unit" [ref=e860]
                        - columnheader "Change" [ref=e861]
                        - columnheader "Relative change" [ref=e862]
                        - columnheader "Numerator" [ref=e863]
                        - columnheader "Denominator" [ref=e864]
                    - rowgroup [ref=e865]:
                      - row [ref=e866]:
                        - rowheader "Call setup success rate" [ref=e867]
                        - cell "99.6" [ref=e868]
                        - cell "99.3" [ref=e869]
                        - cell "PERCENT" [ref=e870]
                        - cell "+0.3 pp" [ref=e871]
                        - cell "+0.3%" [ref=e872]
                        - cell "996" [ref=e873]
                        - cell "1000" [ref=e874]
                - paragraph [ref=e875]:
                  - strong [ref=e876]: Estimated impact
                  - text: "· Estimated extra failed attempts: 0"
                - group [ref=e877]:
                  - generic "Troubleshooting" [ref=e878] [cursor=pointer]
                - group [ref=e879]:
                  - generic "Cause hypothesis & recommended checks" [ref=e880] [cursor=pointer]
              - article [ref=e881]:
                - generic [ref=e886]:
                  - generic [ref=e887]:
                    - heading "Update 17 · RECOVERY" [level=3] [ref=e888]
                    - paragraph [ref=e889]: 15 Sep 10:07:00 – 15 Sep 10:08:00 UTC
                  - generic [ref=e890]:
                    - generic [ref=e891]:
                      - generic [ref=e892]: "Severity:"
                      - text: HIGH
                    - generic [ref=e893]:
                      - generic [ref=e894]: "Technical state:"
                      - text: RECOVERED
                    - generic [ref=e895]: RECOVERY
                - paragraph [ref=e896]:
                  - text: Server detected at
                  - time [ref=e897]: 15 Sep 2026 10:08:10
                  - text: "UTC · Service: VOLTE"
                - heading "Observed evidence" [level=4] [ref=e898]
                - region "KPI evidence for update 17" [ref=e899]:
                  - table [ref=e900]:
                    - caption [ref=e901]: Measured KPIs for update 17
                    - rowgroup [ref=e902]:
                      - row [ref=e903]:
                        - columnheader "KPI" [ref=e904]
                        - columnheader "Actual" [ref=e905]
                        - columnheader "Baseline" [ref=e906]
                        - columnheader "Unit" [ref=e907]
                        - columnheader "Change" [ref=e908]
                        - columnheader "Relative change" [ref=e909]
                        - columnheader "Numerator" [ref=e910]
                        - columnheader "Denominator" [ref=e911]
                    - rowgroup [ref=e912]:
                      - row [ref=e913]:
                        - rowheader "Call setup success rate" [ref=e914]
                        - cell "99.6" [ref=e915]
                        - cell "99.3" [ref=e916]
                        - cell "PERCENT" [ref=e917]
                        - cell "+0.3 pp" [ref=e918]
                        - cell "+0.3%" [ref=e919]
                        - cell "996" [ref=e920]
                        - cell "1000" [ref=e921]
                - paragraph [ref=e922]:
                  - strong [ref=e923]: Estimated impact
                  - text: "· Estimated extra failed attempts: 0"
                - group [ref=e924]:
                  - generic "Troubleshooting" [ref=e925] [cursor=pointer]
                - group [ref=e926]:
                  - generic "Cause hypothesis & recommended checks" [ref=e927] [cursor=pointer]
              - article [ref=e928]:
                - generic [ref=e933]:
                  - generic [ref=e934]:
                    - heading "Update 18 · RECOVERY" [level=3] [ref=e935]
                    - paragraph [ref=e936]: 15 Sep 10:07:00 – 15 Sep 10:08:00 UTC
                  - generic [ref=e937]:
                    - generic [ref=e938]:
                      - generic [ref=e939]: "Severity:"
                      - text: HIGH
                    - generic [ref=e940]:
                      - generic [ref=e941]: "Technical state:"
                      - text: RECOVERED
                    - generic [ref=e942]: RECOVERY
                - paragraph [ref=e943]:
                  - text: Server detected at
                  - time [ref=e944]: 15 Sep 2026 10:08:10
                  - text: "UTC · Service: VOLTE"
                - heading "Observed evidence" [level=4] [ref=e945]
                - region "KPI evidence for update 18" [ref=e946]:
                  - table [ref=e947]:
                    - caption [ref=e948]: Measured KPIs for update 18
                    - rowgroup [ref=e949]:
                      - row [ref=e950]:
                        - columnheader "KPI" [ref=e951]
                        - columnheader "Actual" [ref=e952]
                        - columnheader "Baseline" [ref=e953]
                        - columnheader "Unit" [ref=e954]
                        - columnheader "Change" [ref=e955]
                        - columnheader "Relative change" [ref=e956]
                        - columnheader "Numerator" [ref=e957]
                        - columnheader "Denominator" [ref=e958]
                    - rowgroup [ref=e959]:
                      - row [ref=e960]:
                        - rowheader "Call setup success rate" [ref=e961]
                        - cell "99.6" [ref=e962]
                        - cell "99.3" [ref=e963]
                        - cell "PERCENT" [ref=e964]
                        - cell "+0.3 pp" [ref=e965]
                        - cell "+0.3%" [ref=e966]
                        - cell "996" [ref=e967]
                        - cell "1000" [ref=e968]
                - paragraph [ref=e969]:
                  - strong [ref=e970]: Estimated impact
                  - text: "· Estimated extra failed attempts: 0"
                - group [ref=e971]:
                  - generic "Troubleshooting" [ref=e972] [cursor=pointer]
                - group [ref=e973]:
                  - generic "Cause hypothesis & recommended checks" [ref=e974] [cursor=pointer]
              - article [ref=e975]:
                - generic [ref=e980]:
                  - generic [ref=e981]:
                    - heading "Update 19 · RECOVERY" [level=3] [ref=e982]
                    - paragraph [ref=e983]: 15 Sep 10:07:00 – 15 Sep 10:08:00 UTC
                  - generic [ref=e984]:
                    - generic [ref=e985]:
                      - generic [ref=e986]: "Severity:"
                      - text: HIGH
                    - generic [ref=e987]:
                      - generic [ref=e988]: "Technical state:"
                      - text: RECOVERED
                    - generic [ref=e989]: RECOVERY
                - paragraph [ref=e990]:
                  - text: Server detected at
                  - time [ref=e991]: 15 Sep 2026 10:08:10
                  - text: "UTC · Service: VOLTE"
                - heading "Observed evidence" [level=4] [ref=e992]
                - region "KPI evidence for update 19" [ref=e993]:
                  - table [ref=e994]:
                    - caption [ref=e995]: Measured KPIs for update 19
                    - rowgroup [ref=e996]:
                      - row [ref=e997]:
                        - columnheader "KPI" [ref=e998]
                        - columnheader "Actual" [ref=e999]
                        - columnheader "Baseline" [ref=e1000]
                        - columnheader "Unit" [ref=e1001]
                        - columnheader "Change" [ref=e1002]
                        - columnheader "Relative change" [ref=e1003]
                        - columnheader "Numerator" [ref=e1004]
                        - columnheader "Denominator" [ref=e1005]
                    - rowgroup [ref=e1006]:
                      - row [ref=e1007]:
                        - rowheader "Call setup success rate" [ref=e1008]
                        - cell "99.6" [ref=e1009]
                        - cell "99.3" [ref=e1010]
                        - cell "PERCENT" [ref=e1011]
                        - cell "+0.3 pp" [ref=e1012]
                        - cell "+0.3%" [ref=e1013]
                        - cell "996" [ref=e1014]
                        - cell "1000" [ref=e1015]
                - paragraph [ref=e1016]:
                  - strong [ref=e1017]: Estimated impact
                  - text: "· Estimated extra failed attempts: 0"
                - group [ref=e1018]:
                  - generic "Troubleshooting" [ref=e1019] [cursor=pointer]
                - group [ref=e1020]:
                  - generic "Cause hypothesis & recommended checks" [ref=e1021] [cursor=pointer]
              - article [ref=e1022]:
                - generic [ref=e1027]:
                  - generic [ref=e1028]:
                    - heading "Update 20 · RECOVERY" [level=3] [ref=e1029]
                    - paragraph [ref=e1030]: 15 Sep 10:07:00 – 15 Sep 10:08:00 UTC
                  - generic [ref=e1031]:
                    - generic [ref=e1032]:
                      - generic [ref=e1033]: "Severity:"
                      - text: HIGH
                    - generic [ref=e1034]:
                      - generic [ref=e1035]: "Technical state:"
                      - text: RECOVERED
                    - generic [ref=e1036]: RECOVERY
                - paragraph [ref=e1037]:
                  - text: Server detected at
                  - time [ref=e1038]: 15 Sep 2026 10:08:10
                  - text: "UTC · Service: VOLTE"
                - heading "Observed evidence" [level=4] [ref=e1039]
                - region "KPI evidence for update 20" [ref=e1040]:
                  - table [ref=e1041]:
                    - caption [ref=e1042]: Measured KPIs for update 20
                    - rowgroup [ref=e1043]:
                      - row [ref=e1044]:
                        - columnheader "KPI" [ref=e1045]
                        - columnheader "Actual" [ref=e1046]
                        - columnheader "Baseline" [ref=e1047]
                        - columnheader "Unit" [ref=e1048]
                        - columnheader "Change" [ref=e1049]
                        - columnheader "Relative change" [ref=e1050]
                        - columnheader "Numerator" [ref=e1051]
                        - columnheader "Denominator" [ref=e1052]
                    - rowgroup [ref=e1053]:
                      - row [ref=e1054]:
                        - rowheader "Call setup success rate" [ref=e1055]
                        - cell "99.6" [ref=e1056]
                        - cell "99.3" [ref=e1057]
                        - cell "PERCENT" [ref=e1058]
                        - cell "+0.3 pp" [ref=e1059]
                        - cell "+0.3%" [ref=e1060]
                        - cell "996" [ref=e1061]
                        - cell "1000" [ref=e1062]
                - paragraph [ref=e1063]:
                  - strong [ref=e1064]: Estimated impact
                  - text: "· Estimated extra failed attempts: 0"
                - group [ref=e1065]:
                  - generic "Troubleshooting" [ref=e1066] [cursor=pointer]
                - group [ref=e1067]:
                  - generic "Cause hypothesis & recommended checks" [ref=e1068] [cursor=pointer]
            - group [ref=e1069]:
              - generic "Current impact and cause" [ref=e1070] [cursor=pointer]
```

# Test source

```ts
  93  |       return route.fulfill({ status: 400, json: { code: 'INVALID_RANGE' } });
  94  |     }
  95  |     const count = Math.max(0, Math.min(size, total - number * size));
  96  |     return route.fulfill({ json: {
  97  |       items: Array.from({ length: count }, (_, index) => windowAt(from + (number * size + index) * 60_000)),
  98  |       total, page: number, size, observedAt: new Date(latestEnd).toISOString(),
  99  |     } });
  100 |   });
  101 |   await page.route('**/api/incidents?**', route => {
  102 |     incidentReads++;
  103 |     const query = new URL(route.request().url()).searchParams;
  104 |     const number = Number(query.get('page') ?? 0), size = Number(query.get('size') ?? 20);
  105 |     lastIncidentPage = number;
  106 |     return route.fulfill({ json: {
  107 |       items: Array.from({ length: Math.max(0, Math.min(size, 1000 - number * size)) },
  108 |         (_, index) => incident(number * size + index)),
  109 |       total: 1000, page: number, size,
  110 |     } });
  111 |   });
  112 |   await page.route('**/api/incidents/resource-incident-*', route => {
  113 |     detailReads++;
  114 |     const index = Number(new URL(route.request().url()).pathname.split('-').at(-1));
  115 |     return route.fulfill({ json: incident(index) });
  116 |   });
  117 |   await page.route('**/api/incidents/*/timeline?**', route => route.fulfill({ json: {
  118 |     items: [], total: 0, page: 0, size: 100,
  119 |   } }));
  120 |   await page.route('**/api/incidents/*/detections?**', route => {
  121 |     const query = new URL(route.request().url()).searchParams;
  122 |     const number = Number(query.get('page') ?? 0), size = Number(query.get('size') ?? 20);
  123 |     lastEvidencePage = number;
  124 |     return route.fulfill({ json: {
  125 |       items: Array.from({ length: Math.max(0, Math.min(size, 1000 - number * size)) }, (_, index) => ({
  126 |         ...voiceIncidents[0].latestDetection,
  127 |         detectionId: `resource-detection-${number * size + index}`,
  128 |         sequence: number * size + index + 1,
  129 |       })), total: 1000, page: number, size,
  130 |     } });
  131 |   });
  132 |   return {
  133 |     advance: () => { latestEnd += 60_000; },
  134 |     serviceReads: () => serviceReads,
  135 |     detailReads: () => detailReads,
  136 |     delay: (ms: number) => { responseDelayMs = ms; },
  137 |     reads: () => kpiReads,
  138 |     incidentReads: () => incidentReads,
  139 |     incidentPage: () => lastIncidentPage,
  140 |     evidencePage: () => lastEvidencePage,
  141 |   };
  142 | }
  143 | 
  144 | async function paint(page: Page) {
  145 |   await page.evaluate(() => new Promise<void>(resolve =>
  146 |     requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
  147 | }
  148 | 
  149 | async function navigateToLoginAndExpectCleanup(page: Page) {
  150 |   const retained = await page.evaluateHandle(() => ({
  151 |     state: (window as any).__resource, stream: (window as any).__resource.stream,
  152 |   }));
  153 |   expect(await retained.evaluate(({ state }) => state.active)).toBe(1);
  154 |   // Stay in the same document: goto resets the mock, then the authenticated
  155 |   // session redirects from /login to /dashboard and opens a new stream.
  156 |   await page.evaluate(() => {
  157 |     history.pushState(null, '', '/login');
  158 |     window.dispatchEvent(new PopStateEvent('popstate'));
  159 |   });
  160 |   await expect(page.getByRole('heading', { name: 'Sign in to investigate service issues' })).toBeVisible();
  161 |   await expect(page).toHaveURL(/\/login$/);
  162 |   expect(await retained.evaluate(({ state }) => state === (window as any).__resource)).toBe(true);
  163 |   await expect.poll(() => retained.evaluate(({ state }) => state.active)).toBe(0);
  164 |   expect(await retained.evaluate(({ stream }) => stream.closed)).toBe(true);
  165 |   await retained.dispose();
  166 | }
  167 | 
  168 | test.describe('Browser resource bounds', () => {
  169 |   test.skip(!!process.env.E2E_REAL_LOGIN, 'Controlled dataset; use real login separately for backend evidence');
  170 | 
  171 |   for (const screen of ['overview', 'service', 'investigation']) test(`${screen}: sustained hints remain responsive with bounded REST refreshes`, async ({ page, context }, info) => {
  172 |     test.setTimeout(90_000);
  173 |     const data = await setup(page);
  174 |     const cdp = await context.newCDPSession(page);
  175 |     await cdp.send('Performance.enable');
  176 |     const sample = async () => {
  177 |       await cdp.send('HeapProfiler.collectGarbage');
  178 |       const { metrics } = await cdp.send('Performance.getMetrics');
  179 |       return Object.fromEntries(metrics.filter(metric => ['JSHeapUsedSize', 'Nodes', 'TaskDuration'].includes(metric.name))
  180 |         .map(metric => [metric.name, metric.value]));
  181 |     };
  182 |     await page.goto(screen === 'overview' ? '/dashboard' : screen === 'service' ? `/services/${SCOPE}` : '/incidents/resource-incident-0');
  183 |     await expect(page.locator(screen === 'overview' ? '.overview-panels' : screen === 'service' ? '.service-hero' : '.incident-summary-bar')).toBeVisible();
  184 |     await page.waitForTimeout(300);
  185 |     const records = [];
  186 |     for (const hz of [1, 100]) {
  187 |       data.delay(400);
  188 |       data.advance();
  189 |       const reads = screen === 'investigation' ? data.detailReads : data.serviceReads;
  190 |       const beforeReads = reads(), beforeIncidents = data.incidentReads();
  191 |       const before = await sample();
  192 |       const durationMs = 6000;
> 193 |       const measured = await page.evaluate(async ({ hz, durationMs }) => {
      |                                   ^ Error: page.evaluate: Test timeout of 90000ms exceeded.
  194 |         const state = (window as any).__resource;
  195 |         const frames: number[] = [], longTasks: number[] = [];
  196 |         const observer = new PerformanceObserver(list => {
  197 |           for (const task of list.getEntries()) if (longTasks.length < 100) longTasks.push(task.duration);
  198 |         });
  199 |         observer.observe({ entryTypes: ['longtask'] });
  200 |         performance.clearResourceTimings();
  201 |         let last = performance.now(), running = true, events = 0;
  202 |         const frame = () => {
  203 |           const now = performance.now();
  204 |           if (frames.length < 2000) frames.push(now - last);
  205 |           last = now;
  206 |           if (running) requestAnimationFrame(frame);
  207 |         };
  208 |         requestAnimationFrame(frame);
  209 |         const timer = setInterval(() => { state.stream.hint(); events++; }, 1000 / hz);
  210 |         await new Promise(resolve => setTimeout(resolve, durationMs));
  211 |         clearInterval(timer);
  212 |         running = false;
  213 |         observer.disconnect();
  214 |         return { events, frames, longTasks, activeStreams: state.active };
  215 |       }, { hz, durationMs });
  216 |       const readsDuringLoad = reads() - beforeReads;
  217 |       // REST updates must happen during the burst, rather than only after it ends.
  218 |       expect(readsDuringLoad).toBeGreaterThanOrEqual(hz === 1 ? 2 : 4);
  219 |       expect(readsDuringLoad).toBeLessThanOrEqual(8);
  220 |       expect(measured.activeStreams).toBe(1);
  221 |       await paint(page);
  222 |       const inputStarted = performance.now();
  223 |       if (screen !== 'investigation') {
  224 |         const input = page.getByLabel('From (UTC)', { exact: true });
  225 |         await input.focus();
  226 |         await input.press('ArrowLeft');
  227 |         await paint(page);
  228 |         await expect(input).toBeFocused();
  229 |       }
  230 |       const inputPaintMs = performance.now() - inputStarted;
  231 |       await page.waitForTimeout(1600);
  232 |       const apiRoundTrips = await page.evaluate(() => performance.getEntriesByType('resource')
  233 |         .filter(entry => /^\/api\/(services|incidents|geography)/.test(new URL(entry.name).pathname)
  234 |           && !entry.name.includes('/stream'))
  235 |         .map(entry => ({ path: new URL(entry.name).pathname, durationMs: entry.duration })));
  236 |       const after = await sample();
  237 |       const ordered = measured.frames.sort((a, b) => a - b);
  238 |       records.push({ requestedHintHz: hz, durationMs, events: measured.events,
  239 |         snapshotReadsDuringLoad: readsDuringLoad, incidentPageReads: data.incidentReads() - beforeIncidents,
  240 |         frameGapP95Ms: ordered[Math.ceil(ordered.length * .95) - 1], maxFrameGapMs: ordered.at(-1),
  241 |         longTasksMs: measured.longTasks, inputPaintMs, apiRoundTrips, before, after });
  242 |       if (screen === 'service') {
  243 |         await expect(page.locator('.actual-dot')).toHaveCount(60);
  244 |         await expect(page.locator('[data-window-id]')).toHaveCount(50);
  245 |         await expect(page.locator('.episode-card')).toHaveCount(20);
  246 |       }
  247 |       if (screen === 'investigation') await expect(page.locator('[data-detection-id]')).toHaveCount(20);
  248 |       expect(await page.evaluate(() => (window as any).__resource.active)).toBe(1);
  249 |     }
  250 |     await navigateToLoginAndExpectCleanup(page);
  251 |     await writeFile(info.outputPath('load-performance.json'), JSON.stringify({
  252 |       mode: 'Controlled REST responses and SSE; not LIVE acceptance', screen,
  253 |       scopeCount, incidentTotal: 1000, responseDelayMs: 400, records,
  254 |     }, null, 2));
  255 |     await cdp.detach();
  256 |   });
  257 | 
  258 |   test('bounds history, replaces pages, and retains one tab stream across workspace routes', async ({ page }) => {
  259 |     const data = await setup(page);
  260 |     await page.goto(`/services/${SCOPE}`);
  261 |     await expect(page.locator('.episode-card')).toHaveCount(20);
  262 |     await expect(page.locator('[data-window-id]')).toHaveCount(50);
  263 | 
  264 |     const before = data.reads();
  265 |     await page.getByLabel('From (UTC)', { exact: true }).fill('2026-10-04T11:00');
  266 |     await page.getByLabel('To (UTC, exclusive)').fill('2026-10-05T12:00');
  267 |     await page.getByRole('button', { name: 'Apply time range' }).click();
  268 |     await expect(page.getByRole('alert')).toContainText('at most 24 hours');
  269 |     expect(data.reads()).toBe(before);
  270 | 
  271 |     await page.getByLabel('From (UTC)', { exact: true }).fill('2026-10-04T12:00');
  272 |     await page.getByRole('button', { name: 'Apply time range' }).click();
  273 |     // Dense history is one path; retain every observation without 1,440 DOM markers.
  274 |     await expect.poll(async () => (await page.locator('.service-hero .actual-line').getAttribute('d'))?.match(/[ML]/g)?.length ?? 0).toBe(1440);
  275 |     expect(data.reads() - before).toBe(15);
  276 |     await expect(page.locator('[data-window-id]')).toHaveCount(50);
  277 |     await page.locator('.exact-values > summary').click();
  278 |     const firstWindow = await page.locator('[data-window-id]').first().getAttribute('data-window-id');
  279 |     await page.getByRole('navigation', { name: 'History table pages' }).getByRole('button', { name: 'Next windows' }).click();
  280 |     await expect(page.locator('[data-window-id]').first()).not.toHaveAttribute('data-window-id', firstWindow!);
  281 |     await expect(page.locator('[data-window-id]')).toHaveCount(50);
  282 | 
  283 |     await expect(page.getByRole('button', { name: 'Next incidents' })).toBeEnabled();
  284 |     await page.getByRole('button', { name: 'Next incidents' }).click();
  285 |     await expect(page.locator('.episode-card').first()).toHaveAttribute('data-episode-id', 'resource-episode-20');
  286 |     expect(data.incidentPage()).toBe(1);
  287 |     await expect(page.locator('.episode-card')).toHaveCount(20);
  288 |     const readsBeforeHint = data.incidentReads();
  289 |     await page.evaluate(() => (window as any).__resource.stream.hint());
  290 |     await expect.poll(data.incidentReads).toBeGreaterThan(readsBeforeHint);
  291 |     await expect(page.getByText('Updating…', { exact: true })).toHaveCount(0);
  292 |     await expect(page.locator('.episode-card')).toHaveCount(20);
  293 | 
```